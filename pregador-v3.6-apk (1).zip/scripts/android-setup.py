#!/usr/bin/env python3
"""Ajustes do projeto Android gerado pelo Capacitor (rodado pelo GitHub Actions depois de `cap add android`).
Uso: python3 scripts/android-setup.py <versionCode> <versionName>
- permissões de microfone (gravar aulas / getUserMedia)
- versionCode/versionName (cada build precisa de versionCode maior para instalar por cima)
- ícones do app a partir de icon-512.png / icon-maskable-512.png e cor de fundo #050505
"""
import re, sys
from pathlib import Path
from PIL import Image, ImageDraw

code, name = sys.argv[1], sys.argv[2]
android = Path('android')

# 1) permissões
mf = android / 'app/src/main/AndroidManifest.xml'
t = mf.read_text(encoding='utf8')
for perm in ('RECORD_AUDIO', 'MODIFY_AUDIO_SETTINGS'):
    tag = f'<uses-permission android:name="android.permission.{perm}" />'
    if tag not in t:
        t = t.replace('</manifest>', f'    {tag}\n</manifest>')
mf.write_text(t, encoding='utf8')

# 2) versão
bg = android / 'app/build.gradle'
g = bg.read_text(encoding='utf8')
g, n1 = re.subn(r'versionCode\s+\d+', f'versionCode {code}', g)
g, n2 = re.subn(r'versionName\s+"[^"]*"', f'versionName "{name}"', g)
assert n1 == 1 and n2 == 1, 'não achei versionCode/versionName no build.gradle'
bg.write_text(g, encoding='utf8')

# 3) ícones
res = android / 'app/src/main/res'
icon = Image.open('icon-512.png').convert('RGBA')
mask = Image.open('icon-maskable-512.png').convert('RGBA')
legacy = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
fore = {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}
for d, px in legacy.items():
    out = res / f'mipmap-{d}'
    im = icon.resize((px, px), Image.LANCZOS)
    im.save(out / 'ic_launcher.png')
    circ = Image.new('L', (px * 4, px * 4), 0)
    ImageDraw.Draw(circ).ellipse((0, 0, px * 4 - 1, px * 4 - 1), fill=255)
    circ = circ.resize((px, px), Image.LANCZOS)
    rnd = Image.new('RGBA', (px, px), (0, 0, 0, 0))
    rnd.paste(im, (0, 0), circ)
    rnd.save(out / 'ic_launcher_round.png')
    mask.resize((fore[d], fore[d]), Image.LANCZOS).save(out / 'ic_launcher_foreground.png')
(res / 'values/ic_launcher_background.xml').write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#050505</color>\n</resources>\n', encoding='utf8')
print('android-setup OK:', code, name)
