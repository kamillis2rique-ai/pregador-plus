// Pregador+ — Assistente de IA (Google Gemini)
// Módulo sem imports: main.js entrega os utilitários em initAI(). A chave de API fica só no aparelho
// (IndexedDB, store "settings", chave "ai") e NÃO entra no backup.
let H = null;
export function initAI(helpers) { H = helpers; }

const API = 'https://generativelanguage.googleapis.com/v1beta';
const DEFAULT_MODEL = 'gemini-2.5-flash';
const PRESETS = [
  ['gemini-2.5-flash', 'Gemini 2.5 Flash — rápido (recomendado)'],
  ['gemini-2.5-pro', 'Gemini 2.5 Pro — mais profundo, mais lento'],
  ['gemini-2.5-flash-lite', 'Gemini 2.5 Flash-Lite — o mais leve'],
];
const cfg = { key: '', model: DEFAULT_MODEL, tradition: '', audience: '', models: [] };

export async function loadAIConfig() {
  try { const r = await H.get('settings', 'ai'); if (r?.value) Object.assign(cfg, r.value); } catch (_) { /* sem config ainda */ }
}
const saveCfg = () => H.put('settings', { key: 'ai', value: { ...cfg } });
export const aiReady = () => !!cfg.key;

class AIError extends Error { constructor(msg, code) { super(msg); this.code = code; } }

function systemPrompt() {
  return `Você é um assistente de preparação de pregações para pastores, pregadores e professores bíblicos, dentro do aplicativo Pregador+.
Regras:
- Responda sempre em português do Brasil, em tom claro, pastoral e prático.
- Seja fiel ao texto bíblico e ao seu contexto (histórico, literário e canônico). Evite alegorizações forçadas e versículos usados fora de contexto.
- Cite referências bíblicas com livro, capítulo e versículo. NÃO invente versículos, citações de autores, estatísticas nem fatos históricos. Se não tiver certeza, escreva "(verifique)" em vez de afirmar.
- Só mencione palavras em grego ou hebraico quando tiver segurança, e sugira conferir em um léxico.
- Ilustrações: se forem histórias hipotéticas, deixe claro que são sugestões; nunca as apresente como fatos reais.
- Em temas em que cristãos sérios divergem, apresente as posições com equilíbrio e respeito.
- Você ajuda o pregador; a mensagem é dele. Ofereça material de apoio objetivo, sem discursos prontos longos desnecessários.
- RIGOR COM A PALAVRA DE DEUS: a Bíblia é a autoridade final. A fonte principal é o texto bíblico de referência (Bíblia Portuguesa Mundial, a Bíblia do aplicativo) quando ele for fornecido na mensagem; baseie a interpretação nele e cite versículos SOMENTE com as palavras fornecidas. NUNCA escreva de memória o texto de um versículo entre aspas. Se o texto de uma passagem não foi fornecido, cite só a referência e marque "(conferir no texto)".
- Separe com clareza o que é: (a) o que o texto DIZ (observação), (b) o que o contexto INDICA (interpretação) e (c) a APLICAÇÃO (aplicação é sugestão, não é a Escritura). Não acrescente ao texto o que ele não afirma; não construa doutrina sobre um único versículo isolado; indique o grau de certeza quando houver dúvida.
- SEMPRE EXPLIQUE O PORQUÊ: em toda resposta em texto, termine com a seção "## Por quê", explicando de forma breve o motivo de cada sugestão ou mudança e apontando o versículo ou o princípio bíblico que a sustenta. Em respostas JSON, preencha os campos "why".
- Formato: Markdown simples (títulos com ##, listas com -, **negrito**).${cfg.tradition ? `\nLinha teológica do usuário (respeite-a): ${cfg.tradition}.` : ''}${cfg.audience ? `\nPúblico habitual: ${cfg.audience}.` : ''}`;
}

async function httpError(res) {
  let detail = '';
  try { detail = (await res.json())?.error?.message || ''; } catch (_) { /* corpo vazio */ }
  const st = res.status;
  if (/api key|API_KEY/i.test(detail) && (st === 400 || st === 403)) return new AIError('A chave de API não é válida. Confira em Configurações → Assistente de IA.', 'key');
  if (st === 401 || st === 403) return new AIError('O Google recusou a chave (sem permissão ou região não permitida). ' + detail, 'key');
  if (st === 404) return new AIError('Modelo não encontrado. Em Configurações, toque em “Buscar modelos” e escolha outro.', 'model');
  if (st === 429) return new AIError('Limite de uso atingido (cota gratuita). Aguarde um pouco e tente de novo.', 'quota');
  if (st >= 500) return new AIError('O serviço do Gemini está sobrecarregado. Tente novamente em instantes.', 'server');
  return new AIError('O Gemini recusou o pedido: ' + (detail || 'erro ' + st), 'bad');
}

/** Chama o Gemini com streaming (SSE). Devolve { text, finish }. */
export async function gemini({ prompt, history = [], system, json = false, signal, onText, temperature = 0.7 }) {
  if (!cfg.key) throw new AIError('Cadastre sua chave de API em Configurações → Assistente de IA.', 'nokey');
  if (!navigator.onLine) throw new AIError('Sem internet. A IA precisa de conexão.', 'offline');
  const body = {
    systemInstruction: { parts: [{ text: system || systemPrompt() }] },
    contents: [...history, { role: 'user', parts: [{ text: prompt }] }],
    generationConfig: { temperature, maxOutputTokens: 12000, ...(json ? { responseMimeType: 'application/json' } : {}) },
  };
  let res;
  try {
    res = await fetch(`${API}/models/${encodeURIComponent(cfg.model)}:streamGenerateContent?alt=sse`, {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': cfg.key }, body: JSON.stringify(body), signal,
    });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new AIError('Não consegui falar com o Gemini. Verifique a internet.', 'net');
  }
  if (!res.ok) throw await httpError(res);
  let full = '', finish = '';
  const handle = (ev) => {
    for (const line of ev.split(/\r?\n/)) {
      if (!line.startsWith('data:')) continue;
      const d = line.slice(5).trim();
      if (!d || d === '[DONE]') continue;
      let j; try { j = JSON.parse(d); } catch (_) { continue; }
      if (j.promptFeedback?.blockReason) throw new AIError('O pedido foi bloqueado pelos filtros de segurança do Gemini (' + j.promptFeedback.blockReason + ').', 'blocked');
      const c = j.candidates?.[0];
      const t = (c?.content?.parts || []).filter(p => !p.thought).map(p => p.text || '').join('');
      if (t) { full += t; onText?.(full); }
      if (c?.finishReason) finish = c.finishReason;
    }
  };
  const reader = res.body.getReader(), dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let m;
    while ((m = buf.search(/\r?\n\r?\n/)) >= 0) {
      const ev = buf.slice(0, m);
      buf = buf.slice(m).replace(/^\r?\n\r?\n/, '');
      handle(ev);
    }
  }
  if (buf.trim()) handle(buf);
  if (!full.trim()) throw new AIError(finish === 'SAFETY' ? 'A resposta foi bloqueada pelos filtros de segurança. Reformule o pedido.' : 'O Gemini não devolveu texto. Tente reformular.', 'empty');
  return { text: full, finish };
}

function parseJSON(text) {
  let t = String(text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
  try { return JSON.parse(t); } catch (_) { /* tenta extrair */ }
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch (_) { /* cai no erro */ } }
  throw new AIError('A IA devolveu um formato que não consegui ler. Toque em “Refazer”.', 'json');
}

// ---------- texto → HTML ----------
function md(text) {
  const e = H.esc, out = []; let list = null;
  const inline = s => e(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/(^|[^*])\*([^*\s][^*]*?)\*/g, '$1<i>$2</i>').replace(/`([^`]+)`/g, '<code>$1</code>');
  const flush = () => { if (list) { out.push(`<${list.t}>${list.items.map(i => `<li>${inline(i)}</li>`).join('')}</${list.t}>`); list = null; } };
  for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
    const l = raw.trim();
    if (!l) { flush(); continue; }
    let m;
    if ((m = l.match(/^#{1,4}\s+(.*)/))) { flush(); out.push(`<h4>${inline(m[1])}</h4>`); continue; }
    if ((m = l.match(/^[-*•]\s+(.*)/))) { if (list?.t !== 'ul') { flush(); list = { t: 'ul', items: [] }; } list.items.push(m[1]); continue; }
    if ((m = l.match(/^\d+[.)]\s+(.*)/))) { if (list?.t !== 'ol') { flush(); list = { t: 'ol', items: [] }; } list.items.push(m[1]); continue; }
    flush();
    if (l.startsWith('>')) out.push(`<blockquote>${inline(l.replace(/^>\s*/, ''))}</blockquote>`);
    else out.push(`<p>${inline(l)}</p>`);
  }
  flush();
  return out.join('');
}
const plain = t => String(t || '').replace(/^#{1,4}\s+/gm, '').trim();
const str = v => typeof v === 'string' ? v : Array.isArray(v) ? v.join('\n') : v == null ? '' : String(v);
const words = t => (String(t || '').match(/\S+/g) || []).length;

// ---------- contexto do sermão ----------
function sermonText(x) {
  const L = [], add = (k, v) => { if (v && String(v).trim()) L.push(`${k}: ${String(v).trim()}`); };
  add('Título', x.title === 'Nova mensagem' ? '' : x.title); add('Texto base', x.base); add('Tempo (min)', x.duration);
  add('Proposição', x.proposition); add('Introdução', x.introduction); add('Contexto bíblico', x.context);
  (x.points || []).forEach((p, i) => {
    L.push(`Tópico ${i + 1}: ${p.title || '(sem título)'}`);
    add('  Explicação', p.explanation); add('  Aplicação', p.application); add('  Ilustração', p.illustration);
  });
  add('Conclusão', x.conclusion); add('Apelo', x.appeal); add('Oração', x.prayer);
  return L.join('\n').slice(0, 30000);
}

const OUTLINE_SCHEMA = `Responda APENAS com um objeto JSON válido, sem nenhum texto fora dele, neste formato:
{"title":"","base":"","proposition":"frase única com a ideia central","introduction":"","context":"contexto histórico e literário do texto","points":[{"title":"","explanation":"","application":"","illustration":"","why":"por que este tópico, e nesta ordem, com base no texto"}],"conclusion":"","appeal":"","prayer":"","why":"por que esta estrutura serve ao texto"}
Use de 3 a 5 tópicos. Em "base" coloque a referência principal no formato livro capítulo:versículos. Em "illustration" sugira ilustrações HIPOTÉTICAS e deixe claro que são sugestões.`;
const JSON_WHY = '\n\nInclua no objeto principal o campo "why" (texto curto): por que você fez estas escolhas, com base no texto bíblico fornecido.';

const STYLES = {
  expositivo: ['Expositivo', 'o texto bíblico governa a estrutura: os tópicos nascem das divisões naturais da passagem e cada ponto explica o que o texto diz'],
  textual: ['Textual', 'parte de um versículo ou frase-chave e a desdobra em partes a partir das próprias palavras do texto'],
  tematico: ['Temático / doutrinário', 'parte de um tema ou doutrina e reúne os textos bíblicos que o sustentam, cuidando para não tirar versículos do contexto'],
  narrativo: ['Narrativo / biográfico', 'conduz pela história do texto (cena, tensão, resolução) e extrai a verdade central em cada cena'],
  evangelistico: ['Evangelístico', 'linguagem acessível a quem não conhece a Bíblia, centrado no evangelho, com apelo claro e sem jargão'],
  devocional: ['Devocional / pastoral', 'tom de consolo e cuidado, mais pessoal e reflexivo, com aplicações ao coração'],
  exortativo: ['Exortativo / profético', 'tom de chamado ao arrependimento e à obediência, direto, sempre ancorado no texto e equilibrado pela graça'],
  didatico: ['Didático / ensino bíblico', 'explica com clareza, define termos, usa perguntas e resumos por tópico para ajudar a memorizar'],
  formal: ['Formal / solene', 'linguagem cuidada e reverente, frases completas, sem gírias nem informalidades, adequada ao culto principal'],
  jovens: ['Jovens / informal', 'linguagem direta e atual, exemplos do cotidiano, frases curtas, sem perder a reverência nem a fidelidade ao texto'],
};
const STYLE_OPTIONS = Object.entries(STYLES).map(([k, v]) => [k, v[0]]);

const whyHtml = o => {
  const e = H.esc; let h = '';
  if (str(o.why).trim()) h += `<h4>Por quê</h4><p>${e(str(o.why))}</p>`;
  if (Array.isArray(o.changes) && o.changes.length) h += `<h4>O que mudou e por quê</h4><ul>${o.changes.map(c => `<li><b>${e(str(c.where || c.onde))}</b>: ${e(str(c.change || c.mudanca))}<br><small class="ai-why">Por quê: ${e(str(c.why || c.porque))}</small></li>`).join('')}</ul>`;
  return h;
};
const whyText = o => {
  const L = [];
  if (str(o.why).trim()) L.push('Por quê: ' + str(o.why));
  (o.points || []).forEach((p, i) => { if (str(p.why).trim()) L.push(`Tópico ${i + 1} (${str(p.title)}): ${str(p.why)}`); });
  (Array.isArray(o.changes) ? o.changes : []).forEach(c => L.push(`- ${str(c.where || c.onde)}: ${str(c.change || c.mudanca)} — por quê: ${str(c.why || c.porque)}`));
  return L.join('\n');
};
const flat = o => { const out = []; (function w(v) { if (typeof v === 'string') out.push(v); else if (Array.isArray(v)) v.forEach(w); else if (v && typeof v === 'object') Object.values(v).forEach(w); })(o); return out.join('\n'); };

// ---------- conferência com a Bíblia do app ----------
const nz = t => String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
function quoteIssues(text, checks) {
  const oks = checks.filter(c => c.status === 'ok'), issues = [];
  for (const line of String(text).split('\n')) {
    const here = oks.filter(c => line.includes(c.ref));
    if (!here.length) continue;
    const hay = here.map(c => nz(c.text)).join(' ');
    for (const m of line.matchAll(/[“"«]([^”"»]{18,})[”"»]/g)) {
      const parts = m[1].split(/…|\.\.\./).map(nz).filter(p => p.split(' ').length >= 4);
      if (parts.some(p => !hay.includes(p))) issues.push({ q: m[1].trim(), refs: here.map(c => c.ref) });
    }
  }
  return issues;
}
async function verifyHtml(text, g) {
  const e = H.esc, parts = [];
  if (g?.ok?.length) parts.push(`<p class="ai-src">📖 Texto da Bíblia do app usado como base: ${e(g.ok.join('; '))}</p>`);
  if (g?.missing?.length) parts.push(`<p class="ai-warn">⚠ A Bíblia do app não tem instalado: ${e(g.missing.join('; '))}. Em Bíblia → Instalar Bíblia, para a IA usar o texto do app.</p>`);
  const checks = H.bibleVerify ? await H.bibleVerify(text) : [];
  const li = [];
  for (const c of checks) {
    if (c.status === 'ok') li.push(`<li class="ok">✓ ${e(c.ref)} — existe na Bíblia do app <details><summary>ver o texto do app</summary><p>${e(c.text)}</p></details></li>`);
    else if (c.status === 'missing') li.push(`<li class="warn">⚠ ${e(c.ref)} — capítulo não instalado no app; confira antes de pregar</li>`);
    else if (c.status === 'verse') li.push(`<li class="bad">✗ ${e(c.ref)} — esse versículo não existe (${e(c.book)} ${c.ch} tem ${c.max} versículos)</li>`);
    else if (c.status === 'chapter') li.push(`<li class="bad">✗ ${e(c.ref)} — esse capítulo não existe (${e(c.book)} tem ${c.max} capítulos)</li>`);
  }
  for (const q of quoteIssues(text, checks)) li.push(`<li class="warn">⚠ Citação que não bate com o texto do app: “${e(q.q)}” (${e(q.refs.join('; '))}) — confira</li>`);
  if (li.length) parts.push(`<div class="ai-ver"><b>📖 Conferência com a Bíblia do app (BPM)</b><ul>${li.join('')}</ul></div>`);
  return parts.join('');
}

const previewOutline = o => {
  const e = H.esc;
  return `<h4>${e(str(o.title) || 'Esboço')}</h4>${o.base ? `<p class="muted">${e(str(o.base))}</p>` : ''}${o.proposition ? `<blockquote>${e(str(o.proposition))}</blockquote>` : ''}<ol>${(o.points || []).map(p => `<li><b>${e(str(p.title))}</b><br><span class="muted">${e(str(p.explanation).slice(0, 160))}${str(p.explanation).length > 160 ? '…' : ''}</span>${p.why ? `<br><small class="ai-why">Por quê: ${e(str(p.why))}</small>` : ''}</li>`).join('')}</ol>`;
};

// ---------- ações por contexto ----------
const askField = { id: 'q', label: 'Sua pergunta', type: 'textarea', placeholder: 'Escreva o que quer saber…' };

function sermonActions(ctx) {
  const api = ctx.api;
  const cur = () => api.get();
  const need = (x, msg) => { if (!x.base?.trim() && !(x.title?.trim() && x.title !== 'Nova mensagem')) throw new AIError(msg, 'input'); };
  const pointOptions = () => (cur().points || []).map((p, i) => [String(i), `${i + 1}. ${p.title || 'Tópico sem título'}`]);
  return [
    { icon: '🧩', label: 'Gerar esboço completo', hint: 'A partir do texto base ou do tema (respeita o que você já escreveu)', json: true,
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        return `Crie um esboço de pregação para cerca de ${x.duration || 30} minutos.\n${sermonText(x) ? 'Material já existente (aproveite e respeite o que já foi escrito):\n' + sermonText(x) : 'Ainda não há material.'}\n\n${OUTLINE_SCHEMA}`; },
      preview: previewOutline,
      apply: o => [
        { label: 'Preencher vazios e acrescentar tópicos', fn: () => api.applyOutline(o, 'merge') },
        { label: 'Substituir tudo', danger: true, fn: () => { if (confirm('Substituir todo o conteúdo atual por este esboço?')) api.applyOutline(o, 'replace'); } },
      ] },
    { icon: '🎭', label: 'Moldar ao estilo de mensagem', hint: 'Adapta o seu esboço ao estilo que você vai pregar e explica o porquê', json: true,
      fields: () => [
        { id: 'style', label: 'Estilo da mensagem', type: 'select', options: STYLE_OPTIONS },
        { id: 'level', label: 'Quanto mudar', type: 'select', options: [['light', 'Leve — mantém minhas palavras; ajusta ordem e tom'], ['full', 'Completa — reescreve no estilo escolhido']] },
        { id: 'extra', label: 'Observações (opcional)', type: 'textarea', optional: true, placeholder: 'Ex.: culto de jovens, 25 minutos, sem gírias…' }],
      check: () => { const x = cur(); if (!(x.points || []).length && !String(x.introduction || '').trim()) throw new AIError('Escreva ao menos um esboço (tópicos) para a IA moldar.', 'input'); },
      build: v => { const st = STYLES[v.style];
        return `Reformule o esboço de pregação abaixo no estilo "${st[0]}": ${st[1]}.\nIntensidade: ${v.level === 'full' ? 'completa — reescreva no estilo escolhido' : 'leve — mantenha as palavras e ideias do pregador; ajuste principalmente ordem, tom e transições'}.\nFidelidade: preserve o texto base, a ideia central e TODAS as referências bíblicas do pregador. Não acrescente doutrinas nem passagens que não estejam no esboço; se acrescentar alguma por necessidade, explique o motivo. Não altere o sentido do texto bíblico.${v.extra?.trim() ? `\nObservações do pregador: ${v.extra.trim()}` : ''}\nEm "why" explique por que esta forma serve ao estilo escolhido. Em "changes" liste as mudanças relevantes: [{"where":"onde","change":"o que mudou","why":"por quê"}].\n\nEsboço atual:\n${sermonText(cur())}\n\n${OUTLINE_SCHEMA}`; },
      preview: previewOutline,
      apply: (o, v) => [
        { label: 'Criar nova mensagem neste estilo', fn: () => { closeSheet(); H.createSermon(o, `${cur().title || 'Mensagem'} (${STYLES[v?.style]?.[0] || 'estilo'})`); } },
        { label: 'Substituir esta mensagem', danger: true, keepOpen: true, fn: () => { if (confirm('Substituir o conteúdo atual por esta versão? (O ideal é criar uma nova mensagem e comparar.)')) { api.applyOutline(o, 'replace'); closeSheet(); } } },
      ] },
    { icon: '📄', label: 'Desenvolver em manuscrito', hint: 'Transforma o esboço em texto corrido de pregação, no estilo escolhido',
      fields: () => [
        { id: 'style', label: 'Estilo da mensagem', type: 'select', options: STYLE_OPTIONS },
        { id: 'extra', label: 'Observações (opcional)', type: 'textarea', optional: true, placeholder: 'Ex.: culto de domingo, linguagem formal…' }],
      check: () => { if (!(cur().points || []).length) throw new AIError('Adicione os tópicos antes de pedir o manuscrito.', 'input'); },
      build: v => { const x = cur(), st = STYLES[v.style];
        return `Desenvolva o esboço abaixo como um manuscrito de pregação em texto corrido, no estilo "${st[0]}": ${st[1]}.\nTamanho: cerca de ${(x.duration || 30) * 120} palavras (${x.duration || 30} minutos de fala). Preserve as ideias e as referências do pregador; não acrescente doutrinas. Marque com [ILUSTRAÇÃO SUGERIDA] qualquer ilustração hipotética.${v.extra?.trim() ? `\nObservações do pregador: ${v.extra.trim()}` : ''}\n\nEsboço:\n${sermonText(x)}`; } },
    { icon: '📜', label: 'Contexto do texto base', hint: 'Autor, cenário, contexto literário e observações exegéticas',
      build: () => { const x = cur(); if (!x.base?.trim()) throw new AIError('Preencha o texto base primeiro.', 'input');
        return `Texto base: ${x.base}.\nExplique: autor e destinatários, contexto histórico-cultural, contexto literário (o que vem antes e depois), gênero, ideia central do trecho e 3 observações exegéticas importantes. Seja objetivo. Marque com "(verifique)" qualquer detalhe histórico de que não tenha certeza.`; },
      apply: t => [{ label: 'Inserir em “Contexto bíblico”', fn: () => api.setField('#sContext', plain(t), true) }] },
    { icon: '🧱', label: 'Sugerir tópicos', hint: 'Divisão que siga a estrutura do próprio texto', json: true,
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        return `Sugira de 3 a 5 tópicos para esta pregação, seguindo a estrutura do próprio texto bíblico (sem impor uma estrutura externa). Não repita tópicos já existentes.\n\n${sermonText(x)}\n\nResponda APENAS com JSON: {"points":[{"title":"","explanation":"","application":"","illustration":""}]}`; },
      preview: o => `<ol>${(o.points || []).map(p => `<li><b>${H.esc(str(p.title))}</b><br><span class="muted">${H.esc(str(p.explanation).slice(0, 160))}</span></li>`).join('')}</ol>`,
      apply: o => [{ label: 'Acrescentar estes tópicos', fn: () => api.addPoints(o.points) }] },
    { icon: '🎯', label: 'Ajudar em um tópico', hint: 'Aplicação, ilustração, explicação ou perguntas',
      fields: () => [{ id: 'i', label: 'Tópico', type: 'select', options: pointOptions() }, { id: 'w', label: 'O que gerar', type: 'select', options: [['application', 'Aplicações práticas'], ['illustration', 'Ilustrações (hipotéticas)'], ['explanation', 'Desenvolver a explicação'], ['questions', 'Perguntas para reflexão']] }],
      check: () => { if (!(cur().points || []).length) throw new AIError('Adicione ao menos um tópico primeiro.', 'input'); },
      build: v => { const x = cur(), p = x.points[+v.i]; const what = { application: 'aplicações práticas e concretas para a vida de hoje (3 a 5, curtas)', illustration: '3 ilustrações HIPOTÉTICAS (deixe claro que são sugestões, não fatos)', explanation: 'um desenvolvimento da explicação, fiel ao texto, em 2 a 3 parágrafos curtos', questions: '4 perguntas para reflexão ou discussão' }[v.w];
        return `Esboço atual:\n${sermonText(x)}\n\nFoco no Tópico ${+v.i + 1}: "${p.title}". Gere ${what}.`; },
      apply: (t, v) => v.w === 'questions' ? [] : [{ label: 'Inserir no tópico', fn: () => api.setPointField(+v.i, { application: 'pa', illustration: 'pi', explanation: 'pe' }[v.w], plain(t)) }] },
    { icon: '🚪', label: 'Escrever a introdução', hint: 'Gancho, ponte para o texto e proposição',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.'); return `Escreva uma introdução de cerca de 1 minuto de fala (gancho, ponte para o texto bíblico e proposição).\n\n${sermonText(x)}`; },
      apply: t => [{ label: 'Inserir em “Introdução”', fn: () => api.setField('#sIntro', plain(t), true) }] },
    { icon: '🏁', label: 'Conclusão, apelo e oração', hint: 'Fecha a mensagem com base no que já existe', json: true,
      build: () => { const x = cur(); if (!(x.points || []).length) throw new AIError('Adicione os tópicos antes de pedir a conclusão.', 'input');
        return `Escreva a conclusão, um apelo e uma oração final curta para esta pregação.\n\n${sermonText(x)}\n\nResponda APENAS com JSON: {"conclusion":"","appeal":"","prayer":""}`; },
      preview: o => `<h4>Conclusão</h4><p>${H.esc(str(o.conclusion))}</p><h4>Apelo</h4><p>${H.esc(str(o.appeal))}</p><h4>Oração</h4><p>${H.esc(str(o.prayer))}</p>`,
      apply: o => [{ label: 'Inserir (acrescenta ao que já existe)', fn: () => { api.setField('#sConclusion', o.conclusion, true); api.setField('#sAppeal', o.appeal, true); api.setField('#sPrayer', o.prayer, true); } }] },
    { icon: '🔎', label: 'Revisar fidelidade e clareza', hint: 'Aponta riscos de eisegese, fluxo e o que conferir',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        return `Revise este esboço de pregação. Responda com: 1) Fidelidade ao texto e ao contexto; 2) Riscos (eisegese, texto fora de contexto, alegorização, generalizações); 3) Pontos doutrinários ou fatos que o pregador deve conferir; 4) Fluxo e transições entre os tópicos; 5) Sugestões concretas e curtas. Não reescreva a mensagem.\n\n${sermonText(x)}`; } },
    { icon: '⏱️', label: 'Ajustar ao tempo', hint: 'Estima a duração e sugere cortes ou acréscimos',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        const per = (x.points || []).map((p, i) => `Tópico ${i + 1}: ${words([p.title, p.explanation, p.application, p.illustration].join(' '))} palavras`).join('; ');
        const total = words(sermonText(x));
        return `A mensagem deve durar ${x.duration || 30} minutos. O esboço atual tem cerca de ${total} palavras (≈ ${Math.round(total / 130)} min a 130 palavras por minuto de fala; notas e anotações costumam ser mais curtas que a fala). Por tópico: ${per || 'sem tópicos'}.\nSugira onde cortar ou ampliar para caber no tempo e como distribuir os minutos entre introdução, tópicos e conclusão.\n\n${sermonText(x)}`; } },
    { icon: '❓', label: 'Perguntas difíceis da igreja', hint: 'Antecipa objeções e dúvidas, com resposta bíblica',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        return `Liste 5 perguntas ou objeções difíceis que membros ou visitantes poderiam fazer sobre esta mensagem. Para cada uma: a pergunta, uma resposta pastoral breve e fiel à Bíblia (citando referências), e onde há divergência entre tradições, apresente as posições com equilíbrio. Explique o porquê de cada resposta.\n\n${sermonText(x)}`; } },
    { icon: '👥', label: 'Estudo para célula/grupo', hint: 'Roteiro de discussão a partir da mensagem',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        return `Monte um estudo para pequeno grupo/célula a partir desta mensagem: quebra-gelo, leitura do texto, 5 a 7 perguntas (observação, interpretação, aplicação), um desafio para a semana e oração. Explique o porquê das perguntas principais.\n\n${sermonText(x)}`; } },
    { icon: '📲', label: 'Resumo curto para compartilhar', hint: 'Texto breve para WhatsApp ou redes',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        return `Escreva um resumo curto (até 120 palavras) desta mensagem para compartilhar com a igreja, com o versículo-chave e uma frase de aplicação. Sem inventar nada além do esboço. Depois, em uma linha, explique por que escolheu esse versículo-chave.\n\n${sermonText(x)}`; } },
    { icon: '📖', label: 'Comparar com o capítulo inteiro', hint: 'Confere se o esboço respeita o contexto do capítulo',
      build: () => { const x = cur(); need(x, 'Preencha o título (tema) ou o texto base primeiro.');
        const m = String(x.base || '').match(/^\s*((?:[1-3]\s)?[^\d]+?)\s+(\d+)/); if (!m) throw new AIError('Preencha o texto base com livro e capítulo (ex.: Marcos 4:35-41).', 'input');
        return `Capítulo completo para consulta: ${m[1].trim()} ${m[2]}\n\nCompare o esboço abaixo com o capítulo inteiro (use o texto da Bíblia do app fornecido). Aponte: o que o esboço deixa de fora e importa, versículos vizinhos que mudam o sentido, e riscos de tirar o texto do contexto. Cite os versículos e explique o porquê de cada observação.\n\n${sermonText(x)}`; } },
    { icon: '💬', label: 'Perguntar sobre este esboço', hint: 'Pergunta livre com o esboço como contexto', fields: () => [askField],
      build: v => `Esboço atual:\n${sermonText(cur()) || '(vazio)'}\n\nPergunta do pregador: ${v.q}` },
  ];
}

function verseActions(ctx) {
  const base = `Versículo: ${ctx.ref} — "${ctx.text}"`;
  return [
    { icon: '📖', label: 'Explicar no contexto', hint: 'Significado, contexto e pontos de atenção', build: () => `${base}\nExplique o sentido deste versículo no seu contexto literário e histórico, com 3 observações para o pregador e cuidados para não usá-lo fora de contexto.` },
    { icon: '🔗', label: 'Textos relacionados', hint: 'Passagens que dialogam com este texto', build: () => `${base}\nListe de 5 a 8 passagens bíblicas relacionadas, com uma linha sobre a ligação de cada uma. Use apenas referências que você tem certeza que existem; marque "(verifique)" se tiver dúvida.` },
    { icon: '🌱', label: 'Aplicações para hoje', hint: 'Aplicações práticas e fiéis ao texto', build: () => `${base}\nSugira 4 aplicações práticas para hoje, fiéis ao sentido original do texto, e 2 perguntas de reflexão.` },
    { icon: '🧩', label: 'Esboço de 3 pontos', hint: 'Cria uma mensagem nova a partir deste texto', json: true,
      build: () => `${base}\nCrie um esboço de pregação curto com exatamente 3 tópicos baseado neste texto.\n\n${OUTLINE_SCHEMA}`, preview: previewOutline,
      apply: o => [{ label: 'Criar mensagem com este esboço', fn: () => { closeSheet(); H.createSermon(o, ctx.ref); } }] },
    { icon: '💬', label: 'Perguntar sobre o versículo', hint: 'Pergunta livre', fields: () => [askField], build: v => `${base}\nPergunta: ${v.q}` },
  ];
}

function studyActions(ctx) {
  const tgt = ctx.text ? `Trecho: ${ctx.ref} — "${ctx.text}"` : `Capítulo: ${ctx.ref}`;
  const ins = t => [{ label: 'Inserir no esboço', fn: () => ctx.insert(plain(t)) }];
  return [
    { icon: '📖', label: 'Explicar o trecho', hint: 'Sentido, estrutura e pontos de atenção', apply: ins, build: () => `${tgt}\nExplique este texto: ideia central, estrutura, sentido no contexto do livro, e 3 observações úteis para o pregador. Explique o porquê de cada conclusão a partir do texto.` },
    { icon: '🏛️', label: 'Contexto histórico e cultural', hint: 'Autor, destinatários, época e costumes', apply: ins, build: () => `${tgt}\nDescreva o contexto histórico e cultural relevante (autor, destinatários, situação, costumes). Marque "(verifique)" no que for incerto ou debatido e não invente datas ou fatos.` },
    { icon: '🔑', label: 'Palavras e temas-chave', hint: 'Termos importantes e como se repetem', apply: ins, build: () => `${tgt}\nIdentifique 4 a 6 palavras ou temas-chave deste texto e explique por que importam. Só cite termos do original (grego/hebraico) se tiver certeza e marque "(verifique)" se houver dúvida.` },
    { icon: '🔗', label: 'Textos relacionados', hint: 'Passagens que dialogam com este texto', apply: ins, build: () => `${tgt}\nListe de 5 a 8 passagens relacionadas, com uma linha sobre a ligação de cada uma. Use apenas referências de que tenha certeza; marque "(verifique)" nas demais.` },
    { icon: '⚖️', label: 'Interpretações e cuidados', hint: 'Visões na tradição cristã e riscos de uso fora de contexto', apply: ins, build: () => `${tgt}\nApresente as principais interpretações cristãs deste texto, com equilíbrio e sem escolher lado em pontos divergentes. Diga que cuidados o pregador deve ter para não usar o texto fora de contexto.` },
    { icon: '📚', label: 'Resumir os comentários abertos', hint: 'Resume só o que está na aba Comentários', apply: ins,
      build: () => { if (!String(ctx.comments || '').trim()) throw new AIError('Não há comentários importados para este trecho.', 'input'); return `${tgt}\nResuma os comentários abaixo, atribuindo cada ideia ao autor indicado. Não acrescente opiniões que não estejam neles.\n\n${ctx.comments}`; } },
    { icon: '💬', label: 'Perguntar sobre o trecho', hint: 'Pergunta livre', fields: () => [askField], apply: ins, build: v => `${tgt}\nPergunta: ${v.q}` },
  ];
}

export async function aiTranslate(text) {
  const r = await gemini({ prompt: `Traduza fielmente para o português do Brasil o texto abaixo. Mantenha o sentido e o tom do autor, não resuma, não comente e não acrescente nada. Preserve referências bíblicas. Responda apenas com a tradução.\n\n${String(text).slice(0, 12000)}`, temperature: 0.2 });
  return String(r.text || '').trim();
}

function pageActions(ctx) {
  const cur = () => ctx.api.get();
  return [
    { icon: '🗂️', label: 'Resumir e organizar', hint: 'Transforma suas anotações em tópicos claros', build: () => `Resuma e organize estas anotações de estudo em tópicos claros, sem acrescentar ideias novas e sem alterar referências bíblicas.\n\nTítulo: ${cur().title}\n\n${cur().content.slice(0, 40000)}`,
      apply: t => [{ label: 'Acrescentar à página', fn: () => ctx.api.append(plain(t)) }] },
    { icon: '🌿', label: 'Desenvolver ideias', hint: 'Sugere desdobramentos e perguntas', build: () => `Com base nestas anotações, sugira desdobramentos, perguntas de estudo e textos bíblicos relacionados (só referências de que tenha certeza; marque "(verifique)" nas demais).\n\nTítulo: ${cur().title}\n\n${cur().content.slice(0, 40000)}`,
      apply: t => [{ label: 'Acrescentar à página', fn: () => ctx.api.append(plain(t)) }] },
    { icon: '💬', label: 'Perguntar sobre a página', hint: 'Pergunta livre', fields: () => [askField], build: v => `Anotações:\n${cur().content.slice(0, 40000) || '(vazio)'}\n\nPergunta: ${v.q}` },
  ];
}

function materialActions(ctx) {
  return [
    { icon: '🧩', label: 'Transformar em mensagem', hint: 'Organiza o material em esboço de pregação', json: true,
      build: () => { if (!String(ctx.text || '').trim()) throw new AIError('Não há texto para organizar.', 'input');
        return `Transforme o material abaixo (${ctx.what}) em um esboço de pregação estruturado, preservando as ideias e referências do autor. Organize e complete lacunas com sobriedade; não invente fatos novos.\n\nMaterial:\n${String(ctx.text).slice(0, 60000)}\n\n${OUTLINE_SCHEMA}`; },
      preview: previewOutline,
      apply: o => [{ label: 'Criar mensagem com este esboço', fn: () => { closeSheet(); H.createSermon(o, ctx.title); } }] },
    { icon: '🗂️', label: 'Resumo em tópicos', hint: 'Resumo fiel do conteúdo', build: () => `Resuma em tópicos o material abaixo, sem acrescentar ideias.\n\n${String(ctx.text || '').slice(0, 60000)}` },
  ];
}

// ---------- folha (modal) ----------
let overlay = null, ctrl = null;
export function closeSheet() { ctrl?.abort(); ctrl = null; overlay?.remove(); overlay = null; document.body.classList.remove('ai-open'); }
document.addEventListener('keydown', e => { if (e.key === 'Escape' && overlay) closeSheet(); });

function makeSheet(title, sub) {
  closeSheet();
  overlay = document.createElement('div');
  overlay.className = 'ai-overlay';
  overlay.innerHTML = `<div class="ai-sheet" role="dialog" aria-modal="true" aria-label="${H.esc(title)}"><div class="ai-head"><div><b>✨ ${H.esc(title)}</b><small>${H.esc(sub || '')}</small></div><button type="button" class="ai-x" aria-label="Fechar">✕</button></div><div class="ai-body"></div></div>`;
  document.body.append(overlay);
  document.body.classList.add('ai-open');
  overlay.querySelector('.ai-x').onclick = closeSheet;
  overlay.addEventListener('click', e => { if (e.target === overlay) closeSheet(); });
  return overlay.querySelector('.ai-body');
}

function needKeyHtml() {
  return `<div class="ai-empty"><p><b>Falta a chave de API do Gemini.</b></p><p class="muted">Cole sua chave em Configurações → Assistente de IA. É grátis para começar no Google AI Studio.</p><button type="button" class="btn primary" id="aiGoSettings">Abrir configurações</button></div>`;
}
function bindNeedKey(body) { body.querySelector('#aiGoSettings')?.addEventListener('click', () => { closeSheet(); H.go('settings'); }); }

export function openAISheet(ctx) {
  const titles = { sermon: ['IA no esboço', 'Escolha como a IA pode ajudar'], verse: ['IA no versículo', ctx.ref], study: ['Estudo com IA', ctx.ref], page: ['IA na página', 'Ajuda com suas anotações'], speech: ['IA no esboço falado', 'Organize suas falas'], transcript: ['IA na transcrição', 'Gere um esboço do áudio'] };
  const body = makeSheet(...(titles[ctx.kind] || ['IA', '']));
  if (!aiReady()) { body.innerHTML = needKeyHtml(); bindNeedKey(body); return; }
  const actions = ctx.kind === 'sermon' ? sermonActions(ctx) : ctx.kind === 'verse' ? verseActions(ctx) : ctx.kind === 'study' ? studyActions(ctx) : ctx.kind === 'page' ? pageActions(ctx) : materialActions({ ...ctx, what: ctx.kind === 'speech' ? 'esboço falado' : 'transcrição de uma pregação ou aula' });
  const menu = () => {
    body.innerHTML = `<div class="ai-list">${actions.map((a, i) => `<button type="button" class="ai-act" data-i="${i}"><span class="ai-ico">${a.icon}</span><div><b>${a.label}</b><small>${a.hint}</small></div></button>`).join('')}</div><p class="ai-note">A IA usa a Bíblia instalada no app como fonte principal, mas pode errar. Confira versículos, citações e fatos antes de pregar.</p>`;
    body.querySelectorAll('.ai-act').forEach(b => b.onclick = () => choose(actions[+b.dataset.i]));
  };
  const choose = a => {
    try { a.check?.(); } catch (e) { toastErr(e); return; }
    if (!a.fields) return run(a, {});
    const fs = a.fields();
    body.innerHTML = `<button type="button" class="ai-back">← Voltar</button><h4>${a.label}</h4>${fs.map(f => `<div class="field"><label>${f.label}</label>${f.type === 'select' ? `<select id="aif-${f.id}">${f.options.map(([v, l]) => `<option value="${H.esc(v)}">${H.esc(l)}</option>`).join('')}</select>` : `<textarea id="aif-${f.id}" rows="4" placeholder="${H.esc(f.placeholder || '')}"></textarea>`}</div>`).join('')}<div class="ai-bar"><button type="button" class="btn primary" id="aiGo">Gerar</button></div>`;
    body.querySelector('.ai-back').onclick = menu;
    body.querySelector('#aiGo').onclick = () => {
      const v = {}; fs.forEach(f => v[f.id] = body.querySelector('#aif-' + f.id).value);
      if (fs.some(f => f.type !== 'select' && !f.optional && !v[f.id].trim())) { H.toast('Escreva sua pergunta.'); return; }
      run(a, v);
    };
  };
  const toastErr = e => H.toast(e.message || 'Não foi possível.');
  const run = async (a, v) => {
    body.innerHTML = `<button type="button" class="ai-back">← Voltar</button><h4>${a.label}</h4><div class="ai-out" aria-live="polite"><span class="ai-dots">Pensando…</span></div><div class="ai-bar"></div>`;
    const out = body.querySelector('.ai-out'), bar = body.querySelector('.ai-bar');
    body.querySelector('.ai-back').onclick = () => { ctrl?.abort(); menu(); };
    const stop = document.createElement('button'); stop.type = 'button'; stop.className = 'btn'; stop.textContent = '■ Parar';
    bar.append(stop);
    ctrl = new AbortController();
    stop.onclick = () => ctrl?.abort();
    let raf = 0, partial = '';
    try {
      let prompt = a.build(v);
      const g = a.ground === false ? { block: '', ok: [], missing: [] } : await H.bibleGround(prompt);
      prompt += g.block;
      if (a.json) prompt += JSON_WHY;
      const r = await gemini({ prompt, json: !!a.json, signal: ctrl.signal, temperature: a.json ? 0.6 : 0.7,
        onText: t => { partial = t; if (a.json) { out.innerHTML = `<span class="ai-dots">Montando… ${t.length} caracteres</span>`; return; } cancelAnimationFrame(raf); raf = requestAnimationFrame(() => out.innerHTML = md(t)); } });
      cancelAnimationFrame(raf);
      bar.innerHTML = '';
      const btns = [];
      if (a.json) {
        const o = parseJSON(r.text);
        out.innerHTML = a.preview(o) + whyHtml(o) + await verifyHtml(flat(o), g);
        btns.push(...a.apply(o, v).map(b => ({ ...b, fn: async () => { await b.fn(); if (!b.keepOpen) closeSheet(); } })));
        if (whyText(o)) btns.push({ label: 'Salvar explicação no Caderno', fn: () => H.savePage('Por quê — ' + (ctx.title || a.label), whyText(o)) });
      } else {
        out.innerHTML = md(r.text) + (r.finish === 'MAX_TOKENS' ? '<p class="ai-warn">A resposta foi cortada por limite de tamanho.</p>' : '') + await verifyHtml(r.text, g);
        if (a.apply) btns.push(...a.apply(r.text, v).map(b => ({ ...b, fn: async () => { await b.fn(); closeSheet(); } })));
        btns.push({ label: 'Copiar', fn: async () => { try { await navigator.clipboard.writeText(r.text); H.toast('Copiado'); } catch (_) { H.toast('Não consegui copiar'); } } });
        btns.push({ label: 'Salvar no Caderno', fn: async () => { await H.savePage(ctx.title || ctx.ref || a.label, r.text); } });
      }
      btns.push({ label: '↻ Refazer', fn: () => run(a, v) });
      for (const b of btns) { const el = document.createElement('button'); el.type = 'button'; el.className = 'btn' + (b.danger ? ' danger' : b === btns[0] && a.apply ? ' primary' : ''); el.textContent = b.label; el.onclick = () => b.fn(); bar.append(el); }
    } catch (e) {
      cancelAnimationFrame(raf);
      bar.innerHTML = '';
      if (e.name === 'AbortError') {
        out.innerHTML = (partial && !a.json ? md(partial) : '') + '<p class="ai-warn">Interrompido.</p>';
      } else {
        out.innerHTML = `<p class="ai-err">${H.esc(e.message || 'Erro inesperado.')}</p>`;
        if (e.code === 'key' || e.code === 'nokey') { const g = document.createElement('button'); g.type = 'button'; g.className = 'btn primary'; g.textContent = 'Abrir configurações'; g.onclick = () => { closeSheet(); H.go('settings'); }; bar.append(g); }
      }
      if (e.code !== 'input' && e.code !== 'nokey') { const r2 = document.createElement('button'); r2.type = 'button'; r2.className = 'btn'; r2.textContent = '↻ Tentar de novo'; r2.onclick = () => run(a, v); bar.append(r2); }
    }
  };
  menu();
}

// ---------- configurações ----------
const modelLabel = m => PRESETS.find(p => p[0] === m)?.[1] || m;
export function aiSettingsHtml() {
  const e = H.esc;
  const models = [...new Set([cfg.model, ...PRESETS.map(p => p[0]), ...cfg.models])];
  return `<div class="setting-box ai-card" id="aiCard" style="margin-top:12px"><b>✨ Assistente de IA (Google Gemini)</b>
<p class="muted">Cole sua chave de API do Google AI Studio para a IA ajudar nos esboços. A chave fica só neste aparelho (não entra no backup) e é enviada apenas ao Google.</p>
<div class="field"><label for="aiKey">Chave de API</label><div class="ai-keyrow"><input id="aiKey" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="AIza…" value="${e(cfg.key)}"><button class="btn" id="aiShow" type="button">Mostrar</button></div></div>
<div class="field"><label for="aiModel">Modelo</label><select id="aiModel">${models.map(m => `<option value="${e(m)}" ${m === cfg.model ? 'selected' : ''}>${e(modelLabel(m))}</option>`).join('')}</select></div>
<div class="field"><label for="aiModelCustom">Ou digite o nome do modelo (opcional)</label><input id="aiModelCustom" placeholder="ex.: gemini-2.5-flash" autocapitalize="off" spellcheck="false"></div>
<div class="field"><label for="aiTrad">Sua linha teológica (opcional)</label><input id="aiTrad" placeholder="Ex.: batista, reformada, pentecostal…" value="${e(cfg.tradition)}"></div>
<div class="field"><label for="aiAud">Público habitual (opcional)</label><input id="aiAud" placeholder="Ex.: jovens, culto de domingo, célula…" value="${e(cfg.audience)}"></div>
<div class="actions"><button class="btn primary" id="aiSave" type="button">Salvar</button><button class="btn" id="aiTest" type="button">Testar conexão</button><button class="btn" id="aiModels" type="button">Buscar modelos</button><button class="btn danger" id="aiRemove" type="button">Remover chave</button></div>
<div class="muted" id="aiStatus" role="status" style="margin-top:8px"></div>
<p class="muted"><a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Criar chave no Google AI Studio ↗</a></p>
<details class="ai-tips"><summary>Cuidados com a sua chave</summary><ul>
<li>Não compartilhe a chave (print, grupo, e-mail): quem a tiver usa a sua cota.</li>
<li>Se você ativar cobrança no Google, crie um <b>orçamento com alerta</b> (Google Cloud → Faturamento → Orçamentos e alertas) e ajuste as cotas. No plano gratuito não há cobrança, mas há limite de uso.</li>
<li>Perdeu o celular, trocou de aparelho ou desconfia de vazamento: apague ou troque a chave em aistudio.google.com/apikey e use “Remover chave” aqui.</li>
<li>A chave não entra no backup: em um aparelho novo, cole-a de novo.</li></ul></details>
<p class="muted">Privacidade: o que você enviar à IA vai para os servidores do Google. No plano gratuito do Gemini API, o Google pode usar esses dados para melhorar seus produtos; confira os termos e evite enviar dados pessoais de membros. A IA pode errar: sempre confira versículos, citações e fatos antes de pregar.</p></div>`;
}

export function bindAISettings() {
  const $ = s => document.querySelector(s), status = t => { const el = $('#aiStatus'); if (el) el.textContent = t; };
  const readForm = () => {
    cfg.key = $('#aiKey').value.trim();
    cfg.model = $('#aiModelCustom').value.trim() || $('#aiModel').value || DEFAULT_MODEL;
    cfg.tradition = $('#aiTrad').value.trim(); cfg.audience = $('#aiAud').value.trim();
  };
  $('#aiShow').onclick = () => { const i = $('#aiKey'); const on = i.type === 'password'; i.type = on ? 'text' : 'password'; $('#aiShow').textContent = on ? 'Ocultar' : 'Mostrar'; };
  $('#aiSave').onclick = async () => { readForm(); await saveCfg(); status(cfg.key ? 'Configurações salvas.' : 'Salvo (sem chave: a IA fica desativada).'); H.toast('Configurações da IA salvas'); };
  $('#aiRemove').onclick = async () => { if (!confirm('Remover a chave de API deste aparelho?')) return; cfg.key = ''; $('#aiKey').value = ''; await saveCfg(); status('Chave removida.'); };
  $('#aiTest').onclick = async () => {
    readForm(); await saveCfg(); status('Testando…');
    try { const r = await gemini({ prompt: 'Responda apenas com a palavra OK.', temperature: 0 }); status('✅ Conectado (' + cfg.model + '): ' + r.text.trim().slice(0, 40)); }
    catch (e) { status('❌ ' + (e.message || 'Falhou.')); }
  };
  $('#aiModels').onclick = async () => {
    readForm(); if (!cfg.key) { status('Cole a chave primeiro.'); return; }
    status('Buscando modelos…');
    try {
      const res = await fetch(`${API}/models?pageSize=200`, { headers: { 'x-goog-api-key': cfg.key } });
      if (!res.ok) throw await httpError(res);
      const j = await res.json();
      cfg.models = (j.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent') && /gemini/.test(m.name) && !/(embedding|tts|image|live|audio|robotics|computer|aqa|imagen|veo|learnlm)/.test(m.name)).map(m => m.name.replace(/^models\//, '')).sort().reverse();
      await saveCfg();
      const sel = $('#aiModel'); const all = [...new Set([cfg.model, ...cfg.models])];
      sel.innerHTML = all.map(m => `<option value="${H.esc(m)}" ${m === cfg.model ? 'selected' : ''}>${H.esc(modelLabel(m))}</option>`).join('');
      status(`${cfg.models.length} modelo(s) disponíveis para a sua chave.`);
    } catch (e) { status('❌ ' + (e.message || 'Não consegui listar os modelos.')); }
  };
}

// ---------- aba Assistente (chat) ----------
const chat = { msgs: [], ctxId: '', busy: false };
const CHIPS = ['Explique o contexto de Romanos 12:1-2', 'Dê 3 aplicações de Tiago 1:22 para jovens', 'Como encurtar uma pregação de 40 para 25 minutos?', 'Ajude-me a achar a ideia central de Marcos 4:35-41'];

export function aiViewHtml(sermons) {
  const e = H.esc;
  const sx = [...sermons].sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  const intro = H.head('Assistente de IA', 'Converse sobre estudo, esboços e aplicação.', chat.msgs.length ? '<button class="btn" id="aiClear" type="button">Limpar conversa</button>' : '');
  if (!aiReady()) return `${intro}<div class="card" id="aiView"><h2>Ative o assistente</h2><p class="muted">Cadastre sua chave de API do Gemini para conversar com a IA, gerar esboços e pedir ajuda em cada tópico.</p><button class="btn primary" data-view="settings">Configurar chave</button></div>`;
  return `${intro}<div id="aiView"><div class="field"><label for="aiCtx">Contexto da conversa</label><select id="aiCtx"><option value="">Conversa livre</option>${sx.map(s => `<option value="${e(s.id)}" ${s.id === chat.ctxId ? 'selected' : ''}>Usar a mensagem: ${e(s.title || 'Sem título')}</option>`).join('')}</select></div>
<div id="aiMsgs" class="chat-msgs" aria-live="polite">${chat.msgs.length ? chat.msgs.map(bubble).join('') : '<div class="empty small">Faça uma pergunta ou escolha uma ideia abaixo.</div>'}</div>
<div class="chips" id="aiChips">${CHIPS.map(c => `<button type="button" class="chip" data-chip="${e(c)}">${e(c)}</button>`).join('')}</div>
<form id="aiForm" class="chat-form"><textarea id="aiInput" rows="2" placeholder="Pergunte algo…" aria-label="Sua mensagem"></textarea><button class="btn primary" id="aiSend" type="submit">Enviar</button></form>
<p class="ai-note">A IA usa a Bíblia instalada no app como fonte principal, mas pode errar. Confira versículos, citações e fatos antes de pregar.</p></div>`;
}
function bubble(m, i) {
  return m.role === 'user' ? `<div class="bubble user">${H.esc(m.text).replace(/\n/g, '<br>')}</div>`
    : `<div class="bubble ai" data-i="${i}">${m.text ? md(m.text) : '<span class="ai-dots">Pensando…</span>'}${m.ver || ''}${m.err ? `<p class="ai-err">${H.esc(m.err)}</p>` : ''}${m.text && !m.streaming ? `<div class="bubble-bar"><button type="button" data-do="copy">Copiar</button><button type="button" data-do="save">Salvar no Caderno</button></div>` : ''}</div>`;
}

export function bindAIView() {
  const $ = s => document.querySelector(s);
  if (!$('#aiForm')) { $('#aiClear')?.addEventListener('click', () => { chat.msgs = []; H.render(); }); return; }
  const paint = () => { const box = $('#aiMsgs'); if (box) { box.innerHTML = chat.msgs.length ? chat.msgs.map(bubble).join('') : ''; box.lastElementChild?.scrollIntoView({ block: 'end' }); } };
  $('#aiClear')?.addEventListener('click', () => { ctrl?.abort(); chat.msgs = []; chat.busy = false; H.render(); });
  $('#aiCtx').onchange = e => { chat.ctxId = e.target.value; };
  $('#aiChips').onclick = e => { const c = e.target.closest('[data-chip]'); if (c) { $('#aiInput').value = c.dataset.chip; $('#aiInput').focus(); } };
  $('#aiMsgs').onclick = async e => {
    const b = e.target.closest('[data-do]'); if (!b) return;
    const m = chat.msgs[+b.closest('.bubble').dataset.i]; if (!m) return;
    if (b.dataset.do === 'copy') { try { await navigator.clipboard.writeText(m.text); H.toast('Copiado'); } catch (_) { H.toast('Não consegui copiar'); } }
    else await H.savePage('Conversa com a IA', m.text);
  };
  const send = async () => {
    const inp = $('#aiInput'), text = inp.value.trim();
    if (!text || chat.busy) return;
    inp.value = '';
    const history = chat.msgs.filter(m => m.text && !m.err).slice(-12).map(m => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] }));
    chat.msgs.push({ role: 'user', text });
    const reply = { role: 'ai', text: '', streaming: true };
    chat.msgs.push(reply); chat.busy = true; $('#aiSend').disabled = true; paint();
    let system = systemPrompt(), ctxText = '';
    if (chat.ctxId) { const s = await H.get('sermons', chat.ctxId); if (s) { ctxText = sermonText(s); system += `\n\nO usuário está trabalhando nesta mensagem (use como contexto quando fizer sentido):\n${ctxText}`; } }
    const g = await H.bibleGround(text + '\n' + ctxText); system += g.block;
    ctrl = new AbortController();
    try {
      await gemini({ prompt: text, history, system, signal: ctrl.signal, onText: t => { reply.text = t; if ($('#aiMsgs')) { const el = $('#aiMsgs').lastElementChild; if (el) el.innerHTML = md(t); } } });
      reply.ver = await verifyHtml(reply.text, g).catch(() => '');
    } catch (e) {
      if (e.name !== 'AbortError') reply.err = e.message || 'Erro inesperado.'; else if (!reply.text) chat.msgs.pop();
    } finally { reply.streaming = false; chat.busy = false; if ($('#aiSend')) $('#aiSend').disabled = false; paint(); }
  };
  $('#aiForm').onsubmit = e => { e.preventDefault(); send(); };
  $('#aiInput').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } });
}


// ---------- organizar um esboço colado (preserva as palavras do pregador) ----------
export async function aiOrganize(text) {
  if (!cfg.key) throw new AIError('Configure a chave da IA em Configurações → Assistente de IA.', 'nokey');
  const prompt = `Você vai ORGANIZAR um esboço de pregação já escrito pelo pregador, distribuindo o texto nos campos. REGRAS: copie as palavras do pregador exatamente; NÃO reescreva, NÃO resuma e NÃO acrescente conteúdo novo (nem versículos, nem ilustrações, nem aplicações). Se uma parte não existir no texto, deixe o campo vazio. Em "base" coloque o texto bíblico principal citado. Em "why" explique em 2 ou 3 frases como você dividiu o texto e por quê.\n\n${OUTLINE_SCHEMA}\n\nTEXTO DO PREGADOR:\n"""\n${String(text).slice(0, 40000)}\n"""`;
  const r = await gemini({ prompt, json: true, temperature: 0.1 });
  const o = parseJSON(r.text);
  if (!o || typeof o !== 'object') throw new AIError('A IA não devolveu um esboço válido. Tente de novo.', 'parse');
  return o;
}
