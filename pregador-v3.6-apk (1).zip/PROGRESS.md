# PROGRESSO — Pregador+ (v2.1 → v3.0)
Atualizado: 2026-11-06 08:20. Se a sessão cair, LEIA ISTO e continue da primeira etapa não marcada. Não recomece a auditoria.

## Estado
- [x] Zip extraído em /home/claude/pregador_src (index.html, src/main.js 250 linhas densas, assets/app.css, sw.js, manifest, twa-manifest, netlify.toml, test-app.mjs, GERAR-APK.md)
- [x] Código lido por inteiro; auditoria abaixo concluída
- [x] main.js patchado (itens 1-16 da lista, exceto 9 prompt() e AI)
- [x] Etapa 1: bugs corrigidos em src/main.js via patch1.py (smoke test Playwright OK: voltar, autosave, excluir, favoritos). Falta apenas Etapa 1b: index.html boot, CSS boot
- [x] Etapa 2a: src/ai.js ESCRITO (429 linhas, node --check OK): gemini(), sheet, actions sermon/verse/page/material, settings html, view Assistente
- [x] Etapa 2b-JS: integração em main.js FEITA (patch2.py, syntax OK). FALTA: CSS .ai-* em app.css, teste Playwright da IA com Gemini simulado
- [x] Etapa 2 COMPLETA (CSS + teste Playwright com Gemini simulado OK: aitest.cjs no scratchpad)
- [x] Etapa 3 FEITA (package.json, capacitor, workflow, GERAR-APK.md, test-app.mjs OK)
- [x] Etapa 4: smoke final OK (SW, voltar x5, autosave, offline). Zip: /home/claude/pregador-v3.0-apk.zip. SÓ FALTA entregar e resumir.
- [x] ETAPA 5 COMPLETA (estilos, porquê, Bíblia do app como fonte + conferência; testes OK). sw v11, v3.1.0. Zip: /home/claude/pregador-v3.1-apk.zip. SÓ FALTA entregar.
- [x] ETAPA 6 FEITA (workflow Java21/Node22/Cap8, keystore fixa, android-setup.py, MANUAL-INSTALACAO.md, saveBlob/ditado nativo; simulado local até cap sync OK; gradle NÃO testado). v3.2.0 sw v12. Zip v3.2 a gerar e entregar + responder sugestões de melhoria.
- [x] Etapa 4: smoke final OK (SW, voltar x5, autosave, offline). Zip: /home/claude/pregador-v3.0-apk.zip. SÓ FALTA entregar e resumir.
- [x] ETAPA 5 COMPLETA (estilos, porquê, Bíblia do app como fonte + conferência; testes OK). sw v11, v3.1.0. Zip: /home/claude/pregador-v3.1-apk.zip. SÓ FALTA entregar.
- [x] ETAPA 6 FEITA (workflow Java21/Node22/Cap8, keystore fixa, android-setup.py, MANUAL-INSTALACAO.md, saveBlob/ditado nativo; simulado local até cap sync OK; gradle NÃO testado). v3.2.0 sw v12. Zip v3.2 a gerar e entregar + responder sugestões de melhoria.

## Bugs encontrados (main.js)
1. CRÍTICO: botões Voltar/Cancelar dos editores (sermão, esboço falado, curso, aula, estudo, caderno, página) NÃO funcionam: editores trocam #page.innerHTML sem chamar bindPage, e [data-view]/[data-act] só são ligados por elemento. Correção: delegação de eventos única em document (closest('[data-act],[data-view]')), remover onclick por elemento em bindPage/bindGlobal, juntar o handler 'stop-record' em act.
2. Editor de sermão sem autosave: voltar perde edições. Fazer autosave com debounce 1,2 s + token do editor + flush ao ocultar a página; botão excluir aparece após 1º save.
3. Canvas de manuscrito (editPage): x usa offsetX sem escala (y escalado) → traço desalinhado; salva PNG em branco sempre. Usar getBoundingClientRect para x e y; só salvar se houver traço.
4. Sem excluir/editar: página, estudo, esboço falado, aula, curso, caderno; favoritos sem remover/abrir. Adicionar.
5. editPage sem caderno: opção "Sem caderno".
6. findBibleRefs só reconhece ~45 livros (faltam 1/2 Crônicas, Esdras, Neemias, Ester, Jó, Eclesiastes, Cantares, Lamentações, Oséias, Joel, Amós, Obadias, Jonas, Miquéias, Naum, Habacuque, Sofonias, Ageu, Zacarias, Malaquias), sem tolerância a acento, sem limite de palavra. Gerar regex a partir de BIBLE_BOOKS.
7. render() sem try/catch nem proteção de corrida; hashchange + clique renderizam 2x. Adicionar token de render, tela de erro, dedupe via S._renderedView.
8. put/del resolvem em request.onsuccess; usar tx.oncomplete. d.onversionchange fecha o DB sem reabrir. Handler global unhandledrejection (Quota → aviso).
9. Wake lock continua ao sair da tela Pregar sem usar "voltar"; pausar timer sem tick final perde <0,5 s. preach-note usa prompt().
10. Dictation: rec.start() duplo lança InvalidStateError (try/catch).
11. Bíblia: all('bible') (1189 caps) recarrega a cada tecla/render; cache com contador de versão; throttle de render no download (a cada 20).
12. Busca global: JSON.stringify inclui drawing (base64) → falsos positivos; excluir drawing/blobData; notas → notebooks.
13. Backup: incluir chave de IA seria vazamento → excluir settings 'ai' do export; ao restaurar, preservar 'ai' (clearDB apaga); sanitizar ids com aspas/<>& no import (usados em atributos HTML); opção de backup leve sem áudios/arquivos.
14. Acessibilidade: cards clicáveis sem role=button/tabindex; Enter/Espaço.
15. Áudio: URL.createObjectURL por render sem revoke.
16. Esboço falado: texto diz "poderá virar sermão" mas não existe → botão "Transformar em mensagem" (com IA se houver chave, senão local).

## Bugs em config/PWA
- netlify.toml CSP connect-src só tem api.midvash.com → adicionar https://generativelanguage.googleapis.com (senão Gemini é bloqueado).
- sw.js: VERSION v9→v10; navigation preload sem timeout (competir com timeout); precache incluir ./src/ai.js.
- manifest: "id" melhor "/"; adicionar screenshots (gerar com Playwright), description.
- index.html: faltam meta description, apple-touch-icon, noscript, tela de erro se o módulo falhar.
- twa-manifest: host/URLs com SEU-SITE placeholder; assetlinks.json com fingerprint placeholder (documentado).
- Java existe no ambiente (/usr/bin/java), mas Android SDK provavelmente não: APK não será compilado aqui; entregar pronto-para-build (PWABuilder/Bubblewrap/Capacitor+GitHub Actions) e dizer isso honestamente.

## Design da IA (Gemini)
- ai.js módulo sem imports; initAI(helpers) recebe get/put/all/esc/toast/uid/now/ic/render/S de main.js.
- Config em settings key 'ai' {key, model(default gemini-2.5-flash), tradition, audience, models[]}; fica só no aparelho, fora do backup.
- REST: POST https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse, header x-goog-api-key, systemInstruction, generationConfig (responseMimeType application/json nos modos JSON). Botão "Buscar modelos" (GET /v1beta/models) porque nomes mudam. Erros mapeados (400 chave, 403, 404 modelo, 429 cota, 503).
- System prompt pt-BR: fiel ao texto/contexto, não inventar versículos/citações/fatos, marcar ilustrações como hipotéticas, "verifique" quando incerto, equilíbrio em temas divergentes, respeitar linha teológica configurada.
- Ações: no editor de sermão (esboço completo JSON, contexto do texto, sugerir tópicos, ajudar num tópico [ilustração/aplicação/explicação/perguntas], introdução, conclusão+apelo+oração, revisar fidelidade, ajustar ao tempo por contagem de palavras, perguntar livre); no versículo da Bíblia (explicar, relacionados, aplicações, esboço de 3 pontos); na página do caderno (resumir/organizar, desenvolver, perguntar); no esboço falado e na transcrição (gerar mensagem); aba "Assistente" (chat com sermão como contexto). Resultado: prévia, Copiar, Salvar no Caderno, Inserir/Aplicar (não destrutivo por padrão), Parar, Refazer.
- Privacidade: texto vai ao Google; avisar na tela de configuração.


## ===== FASE 2 (pedido 08/11 13:13: "Faça todas por etapa" = as 10 sugestões) =====
Ordem e estado (marque [x] ao concluir; cada etapa: implementar → testar (Playwright) → log aqui → bump sw/package/twa → zip → SendUserFile):
- [x] E1 Colar esboço (como colado / organizar sem IA / organizar com IA preservando palavras) → botão em Mensagens
- [x] E2 Tempo por tópico (campo minutos por tópico + alerta por cor na tela Pregar, sem som/vibração)
- [x] E3 Histórico de pregações (store 'history' → DB v6; salvar ao encerrar: data, local, tempo real, notas; view + backup/restore incluem 'history')
- [x] E4 Nota em versículo na pregação (toca na referência: mostra nota; toca de novo/fora: some; salva em sermão.verseNotes)
- [x] E5 Exportar mensagem: texto (.txt/.md), PDF (gerador próprio, sem lib) e compartilhar (saveBlob/Share)
- [x] E6 Outras traduções: importador (arquivo JSON/URL do usuário) + seletor de leitura; IA continua fundamentada na BPM (principal)
- [x] E7 Lembrete de backup (banner na Home após 7 dias; registra lastBackup)
- [x] E8 Mais usos da IA: perguntas difíceis, estudo de célula, resumo curto, comparar com capítulo inteiro
- [x] E9 Cuidados da chave (texto em Configurações + manual: limite de gasto, revogar)
- [x] E10 Sincronizar entre aparelhos: SEM servidor = "Mesclar backup" (mais recente vence por updatedAt) + manual; sync automática exigiria backend (não feita)
Versão alvo final: 3.3.0 (sw v13). Arquivos de teste no scratchpad: aitest.cjs, ai2.cjs, final.cjs, shots.cjs (servem de base).
- E1–E4 FEITOS e testados (e14.cjs no scratchpad, patch5.py). Próximo: E5 (exportar txt/PDF/compartilhar).
- E5, E7, E9 FEITOS e testados (patch6.py, e57.cjs: PDF válido qpdf/pdftotext, banner backup). Próximo: E6 (outras traduções), E8 (mais IA), E10 (mesclar backup), depois regressão+zip final.
- [x] E6, E8, E10 FEITOS (patch7-9, e6.cjs). Regressão OK (e14, final, ai2, aitest, test-app). sw v14. Falta: zip v3.3 final, memória, resposta final.

## ===== FASE 3 (09/11): Estúdio de estudo =====
Decisões do usuário: NÃO mexer na área de Pregar. Estúdio separado: tablet/PC = tela dividida (esboço | estudo); celular = tela por cima (pop-up). Bíblia 2: Almeida 1911 (domínio público, fonte damarals/biblias release ALM1911.json; 1898 não achada com licença) embutida sob demanda + importador. Comentários: português primeiro; inglês PD só traduzido pela IA e marcado. IA explica versículo/capítulo sob pedido, separada dos comentários.
- [ ] F1 baixar ALM1911.json, converter p/ formato do app (version 'ALM1911', ids T:ALM1911:Livro.cap)
- [ ] F2 Estúdio dividido/pop-up no editor de mensagem (abas: Bíblia 2 versões, Comentários, IA, Notas) + inserir no tópico
- [ ] F3 Comentários (importador + rótulo autor/obra) e IA de estudo (tradução marcada)
- [ ] F4 testes, regressão, zip v3.4, manual
- [x] F1–F3 FEITOS: src/studio.js (Estúdio), data/alm1911.json, ai.js studyActions/aiTranslate, CSS, sw v15, teste f2.cjs ok (tablet+cel). Falta: regressão final, zip v3.4, memória.
- [x] FASE 4 (plano, revisão pós-pregação, ilustrações+aba no Estúdio, busca ampliada) feita: patch10, f4.cjs ok. v3.5.0 sw v16. Falta: regressão final + zip v3.5 + memória.
- [x] FASE 5: menu enxuto (TABS, Mais, Pregar no bottom nav, Home sem Resumo). v3.6.0 sw v17. Code-splitting NÃO feito (risco). Falta: zip v3.6, memória.
