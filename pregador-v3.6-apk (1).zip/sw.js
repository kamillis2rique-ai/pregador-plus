/* Pregador+ Pro — Service Worker
 * - Pré-cache do "app shell" (abre instantaneamente e 100% offline)
 * - Navegação: rede primeiro (3 s) com pré-carregamento; cai no cache/offline.html
 * - Arquivos estáticos: stale-while-revalidate (rápido + sempre se atualiza)
 * - Fontes e ícones: cache primeiro
 * Para publicar uma atualização, aumente VERSION.
 */
const VERSION = 'v17';
const PREFIX = 'pregador-plus-pro-';
const SHELL = `${PREFIX}shell-${VERSION}`;
const RUNTIME = `${PREFIX}runtime-${VERSION}`;
const NAV_TIMEOUT_MS = 3000;

const PRECACHE = [
  './', './index.html', './offline.html',
  './assets/app.css', './src/main.js', './src/ai.js', './src/studio.js', './src/boot.js', './manifest.webmanifest',
  './icon.svg', './icon-192.png', './icon-512.png', './icon-maskable-512.png',
  './assets/fonts/outfit.woff2', './assets/fonts/jbmono-700.woff2'
];

// Pré-cache tolerante: se um arquivo falhar (ex.: build renomeou), o app ainda instala.
self.addEventListener('install', e => e.waitUntil((async () => {
  const c = await caches.open(SHELL);
  await Promise.allSettled(PRECACHE.map(u => c.add(new Request(u, { cache: 'reload' }))));
  await self.skipWaiting();
})()));

self.addEventListener('activate', e => e.waitUntil((async () => {
  for (const k of await caches.keys()) {
    if (k.startsWith(PREFIX) && k !== SHELL && k !== RUNTIME) await caches.delete(k);
  }
  if (self.registration.navigationPreload) await self.registration.navigationPreload.enable().catch(() => {});
  await self.clients.claim();
})()));

const timeout = (ms) => new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms));

async function handleNavigation(e) {
  const shell = await caches.open(SHELL);
  try {
    const preload = e.preloadResponse ? await Promise.race([e.preloadResponse, timeout(NAV_TIMEOUT_MS)]).catch(() => null) : null;
    const res = await Promise.race([preload ? Promise.resolve(preload) : fetch(e.request), timeout(NAV_TIMEOUT_MS)]);
    if (res && res.ok) { shell.put('./index.html', res.clone()).catch(() => {}); return res; }
    throw new Error('bad response');
  } catch {
    return (await shell.match('./index.html')) || (await shell.match('./')) || (await shell.match('./offline.html')) || Response.error();
  }
}

async function staleWhileRevalidate(e, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = (await caches.match(e.request, { ignoreSearch: true }));
  const network = fetch(e.request).then(r => {
    if (r.ok && r.type === 'basic') cache.put(e.request, r.clone());
    return r;
  }).catch(() => null);
  if (cached) { e.waitUntil(network); return cached; }
  return (await network) || Response.error();
}

async function cacheFirst(e) {
  const cached = await caches.match(e.request, { ignoreSearch: true });
  if (cached) return cached;
  try {
    const r = await fetch(e.request);
    if (r.ok && r.type === 'basic') (await caches.open(RUNTIME)).put(e.request, r.clone());
    return r;
  } catch { return Response.error(); }
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (u.origin !== location.origin) return;       // API da Bíblia etc.: o app já guarda no IndexedDB
  if (req.headers.has('range')) return;            // áudio/PDF com Range: o navegador trata
  if (u.pathname.startsWith('/.well-known/')) return;
  if (req.mode === 'navigate') { e.respondWith(handleNavigation(e)); return; }
  if (/\.(woff2?|png|svg|ico|webp|jpg)$/i.test(u.pathname)) { e.respondWith(cacheFirst(e)); return; }
  e.respondWith(staleWhileRevalidate(e, SHELL));
});

self.addEventListener('message', e => {
  if (e.data === 'skipWaiting' || e.data?.type === 'SKIP_WAITING') self.skipWaiting();
  if (e.data?.type === 'GET_VERSION') e.source?.postMessage({ type: 'VERSION', version: VERSION });
});
