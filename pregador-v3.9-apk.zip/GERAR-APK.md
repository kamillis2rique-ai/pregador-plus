# Pregador+ Pro v3.0 — PWA e APK

O app é um PWA (manifest + service worker + offline). Há 3 caminhos para ter o APK. Escolha um.

## A) Mais fácil: PWABuilder (sem instalar nada)
1. Suba esta pasta no **Netlify** (arraste a pasta; o `netlify.toml` já cuida dos cabeçalhos e da CSP).
2. Abra https://www.pwabuilder.com, cole a URL do site → **Package for stores → Android**.
3. Package ID `com.pregadorplus.app`, assinatura **New**. **Guarde o .keystore e a senha** (sem eles não dá para atualizar o app).
4. O zip traz o `.apk` (instala direto), o `.aab` (Play Store) e o `assetlinks.json` certo.
5. Coloque o SHA-256 em `.well-known/assetlinks.json` (troque `COLE_AQUI_O_SHA256...`) e republique o site. Sem isso o APK mostra a barra do Chrome no topo.

## B) Bubblewrap (linha de comando)
```
npm i -g @bubblewrap/cli
# troque SEU-SITE.netlify.app em twa-manifest.json
bubblewrap init --manifest=https://SEU-SITE.netlify.app/manifest.webmanifest
bubblewrap build
```
Precisa de JDK 17 e Android SDK (o Bubblewrap oferece instalar). Depois faça o passo 5 do caminho A.

## C) APK que não depende de site: Capacitor + GitHub Actions (recomendado para uso pessoal)
O app roda empacotado dentro do APK (offline desde o primeiro uso, sem assetlinks). O guia passo a passo está em **MANUAL-INSTALACAO.md**.
- Workflow: `.github/workflows/android-apk.yml` (Node 22, Java 21, Capacitor 8).
- Assinatura fixa em `signing/debug.keystore` + `versionCode` = número do build, para atualizar por cima sem perder dados.
- No APK, o backup usa o compartilhamento do Android e o ditado usa o reconhecimento do Google (plugin nativo).
- Não foi compilado no ambiente de desenvolvimento (sem Android SDK); o log do Actions indica qualquer falha.

## Teste local
```
npm test          # verificações estáticas
npm run serve     # abre em http://localhost:8080
```
No Chrome: DevTools → Lighthouse → Progressive Web App.

## IA (Gemini)
Em **Configurações → Assistente de IA** cole a chave do Google AI Studio (https://aistudio.google.com/apikey).
- A chave fica só no aparelho e **não entra no backup**.
- O endereço `generativelanguage.googleapis.com` já está liberado na CSP (`netlify.toml`). Se hospedar em outro lugar, libere em `connect-src`.
- Se o modelo padrão (`gemini-2.5-flash`) for descontinuado, use **Buscar modelos** nas configurações.
- O que você enviar à IA vai para o Google. Não envie dados pessoais de membros.

## Antes de publicar uma atualização
- Aumente `VERSION` em `sw.js`; no APK (A/B), aumente `appVersionCode` só se mudar a casca.
- Os dados ficam no IndexedDB do aparelho. Faça **Backup** antes de desinstalar.
- Play Store: conta de desenvolvedor, política de privacidade e capturas de tela (já há em `screenshots/`).
