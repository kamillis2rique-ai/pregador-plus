// Copia só o que o app precisa para a pasta www/ (usada pelo Capacitor).
import fs from 'node:fs';
const files = ['index.html', 'offline.html', 'sw.js', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png'];
const dirs = ['src', 'assets', 'screenshots', 'data'];
fs.rmSync('www', { recursive: true, force: true });
fs.mkdirSync('www', { recursive: true });
for (const f of files) fs.copyFileSync(f, 'www/' + f);
for (const d of dirs) fs.cpSync(d, 'www/' + d, { recursive: true });
console.log('www/ pronto');
