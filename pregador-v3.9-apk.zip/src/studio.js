// Estúdio de estudo: painel separado do editor de mensagem (tela dividida no tablet/PC, tela por cima no celular).
// Não toca na área de Pregar. Recebe helpers de main.js e a "api" do editor de mensagem.
import { openAISheet, aiReady, aiTranslate } from './ai.js';

let H = null;
export function initStudio(helpers) { H = helpers; }

const ST = { tab: 'bible', book: 'João', ch: 3, a: 'BPM', b: '', sel: [], work: '', dest: 'new' };
let root = null, api = null, anchorEl = null, obs = null;
const $ = s => (root ? root.querySelector(s) : null);
const esc = s => H.esc(s);

export const studioOpen = () => !!root;

export function closeStudio() {
  obs?.disconnect(); obs = null;
  root?.remove(); root = null; api = null; anchorEl = null;
  document.body.classList.remove('studio-open');
}

export function toggleStudio(editorApi) {
  if (root) return closeStudio();
  api = editorApi;
  anchorEl = document.querySelector('#sTitle');
  const base = String(api.get().base || '');
  const m = base.match(/^\s*((?:[1-3]\s)?[^\d]+?)\s+(\d+)/);
  if (m) {
    const bn = H.norm(m[1].trim());
    const bk = H.BIBLE_BOOKS.find(b => H.norm(b[0]) === bn) || (bn === 'salmo' ? H.BIBLE_BOOKS.find(b => b[0] === 'Salmos') : null);
    if (bk && +m[2] >= 1 && +m[2] <= bk[2]) { ST.book = bk[0]; ST.ch = +m[2]; ST.sel = []; }
  }
  root = document.createElement('aside');
  root.id = 'studio';
  root.setAttribute('role', 'complementary');
  root.setAttribute('aria-label', 'Estúdio de estudo');
  document.body.append(root);
  document.body.classList.add('studio-open');
  // se o editor for trocado/fechado, fecha o estúdio
  obs = new MutationObserver(() => { if (anchorEl && !document.contains(anchorEl)) closeStudio(); });
  obs.observe(document.querySelector('#page') || document.body, { childList: true, subtree: true });
  draw();
}

const bookInfo = () => H.BIBLE_BOOKS.find(b => b[0] === ST.book) || H.BIBLE_BOOKS[0];

async function chapterOf(ver, book, ch) {
  const r = await H.get('bible', ver === 'BPM' ? `${book}.${ch}` : `T:${ver}:${book}.${ch}`);
  return r?.verses?.length ? r.verses : null;
}

async function versions() { return ['BPM', ...(await H.transNames())]; }

function selRange() {
  const n = [...ST.sel].sort((x, y) => x - y);
  if (!n.length) return null;
  return n.length === 1 || n[n.length - 1] - n[0] + 1 === n.length ? (n.length === 1 ? `${n[0]}` : `${n[0]}-${n[n.length - 1]}`) : n.join(',');
}
const selRef = () => { const r = selRange(); return r ? `${ST.book} ${ST.ch}:${r}` : `${ST.book} ${ST.ch}`; };

async function selText(ver) {
  const vs = (await chapterOf(ver || ST.a, ST.book, ST.ch)) || [];
  const set = new Set(ST.sel.map(String));
  const picked = vs.filter(v => set.has(String(parseInt(v[0]))));
  return picked.map(v => `${v[0]} ${v[1]}`).join(' ');
}

function destOptions() {
  const pts = (api.get().points || []).map((p, i) => `<option value="p:${i}">Tópico ${i + 1}${p.title ? ' — ' + esc(String(p.title).slice(0, 28)) : ''}</option>`).join('');
  const sel = v => (ST.dest === v ? ' selected' : '');
  return `<option value="new"${sel('new')}>Novo tópico</option>${pts}<option value="intro"${sel('intro')}>Introdução</option><option value="ctx"${sel('ctx')}>Contexto bíblico</option><option value="concl"${sel('concl')}>Conclusão</option>`;
}

function insertInto(text) {
  const d = ST.dest || 'new';
  if (!String(text || '').trim()) return;
  if (d === 'new') api.addPoints([{ title: '', explanation: text }]);
  else if (d === 'intro') api.setField('#sIntro', text, false);
  else if (d === 'ctx') api.setField('#sContext', text, false);
  else if (d === 'concl') api.setField('#sConclusion', text, false);
  else if (d.startsWith('p:')) api.setPointField(+d.slice(2), 'pe', text);
}

async function draw() {
  if (!root) return;
  const tabs = [['bible', 'Bíblia'], ['comm', 'Comentários'], ['ill', 'Ilustrações'], ['ai', 'IA']];
  root.innerHTML = `<header class="st-head"><button class="btn st-close" id="stClose" aria-label="Fechar estúdio">← Esboço</button><b class="st-title">Estúdio de estudo</b><nav class="st-tabs">${tabs.map(([k, l]) => `<button class="${ST.tab === k ? 'on' : ''}" data-tab="${k}">${l}</button>`).join('')}</nav></header><div class="st-body" id="stBody"></div><footer class="st-foot" id="stFoot"></footer>`;
  $('#stClose').onclick = closeStudio;
  root.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { ST.tab = b.dataset.tab; draw(); });
  if (ST.tab === 'bible') await drawBible();
  else if (ST.tab === 'comm') await drawComm();
  else if (ST.tab === 'ill') await drawIll();
  else drawAI();
  drawFoot();
}

function drawFoot() {
  const f = $('#stFoot'); if (!f) return;
  if (ST.tab === 'ill') { f.innerHTML = `<span class="st-selref">Inserir em</span><select id="stDest" aria-label="Destino no esboço">${destOptions()}</select>`; $('#stDest').onchange = e => ST.dest = e.target.value; return; }
  if (ST.tab === 'ai' || (!ST.sel.length && ST.tab === 'bible')) { f.innerHTML = ST.tab === 'bible' ? '<small class="muted">Toque nos versículos para selecionar e levar ao esboço.</small>' : ''; return; }
  if (!ST.sel.length) { f.innerHTML = ''; return; }
  f.innerHTML = `<span class="st-selref">${esc(selRef())}</span><select id="stDest" aria-label="Destino no esboço">${destOptions()}</select><button class="btn primary" id="stIns">Inserir</button><button class="btn" id="stClr" aria-label="Limpar seleção">✕</button>`;
  $('#stDest').onchange = e => ST.dest = e.target.value;
  $('#stClr').onclick = () => { ST.sel = []; draw(); };
  $('#stIns').onclick = async () => {
    const t = await selText(ST.a);
    insertInto(`${selRef()} (${ST.a}) — “${t.replace(/^\d+\s/, '').replace(/\s(\d+)\s/g, ' ')}”`);
  };
}

// ---------------- Bíblia ----------------
async function drawBible() {
  const vers = await versions();
  if (!vers.includes(ST.a)) ST.a = 'BPM';
  if (ST.b && !vers.includes(ST.b)) ST.b = '';
  const info = bookInfo();
  const [va, vb] = await Promise.all([chapterOf(ST.a, ST.book, ST.ch), ST.b ? chapterOf(ST.b, ST.book, ST.ch) : null]);
  const mapB = new Map((vb || []).map(v => [String(parseInt(v[0])), v[1]]));
  const sel = new Set(ST.sel.map(String));
  const verOpts = (cur, withNone) => `${withNone ? `<option value=""${cur === '' ? ' selected' : ''}>— comparar com —</option>` : ''}${vers.map(v => `<option value="${esc(v)}"${cur === v ? ' selected' : ''}>${esc(v)}</option>`).join('')}`;
  const hasAlm = vers.includes('ALM1911');
  let list;
  if (va) {
    list = va.map(v => { const n = String(parseInt(v[0])); return `<div class="st-v${sel.has(n) ? ' sel' : ''}" data-n="${esc(n)}" tabindex="0" role="button"><span class="st-n">${esc(v[0])}</span><div><span>${esc(v[1])}</span>${ST.b && mapB.has(n) ? `<div class="st-v2"><b>${esc(ST.b)}</b> ${esc(mapB.get(n))}</div>` : ''}</div></div>`; }).join('');
  } else {
    list = `<div class="empty">${ST.a === 'BPM' ? `${esc(ST.book)} ${ST.ch} ainda não está neste aparelho. Baixe em <b>Bíblia → Instalar Bíblia</b>.` : `${esc(ST.book)} ${ST.ch} não existe em ${esc(ST.a)}.`}</div>`;
  }
  if (!root) return;
  $('#stBody').innerHTML = `<div class="st-nav"><select id="stBook" aria-label="Livro">${H.BIBLE_BOOKS.map(b => `<option${b[0] === ST.book ? ' selected' : ''}>${esc(b[0])}</option>`).join('')}</select><select id="stCh" aria-label="Capítulo">${Array.from({ length: info[2] }, (_, i) => `<option${i + 1 === ST.ch ? ' selected' : ''}>${i + 1}</option>`).join('')}</select><button class="btn" id="stPrev" aria-label="Capítulo anterior">‹</button><button class="btn" id="stNext" aria-label="Próximo capítulo">›</button></div>
  <div class="st-nav"><select id="stA" aria-label="Versão principal">${verOpts(ST.a, false)}</select><select id="stB" aria-label="Segunda versão">${verOpts(ST.b, true)}</select></div>
  ${hasAlm ? '' : '<div class="st-inst"><b>Almeida 1911</b> (domínio público) — 2ª versão, offline. <button class="btn tiny primary" id="stAlm">Instalar</button> <span class="muted" id="stAlmMsg"></span></div>'}
  <div class="st-verses">${list}</div>`;
  const go = (b, c) => { ST.book = b; ST.ch = c; ST.sel = []; draw(); };
  $('#stBook').onchange = e => go(e.target.value, 1);
  $('#stCh').onchange = e => go(ST.book, +e.target.value);
  $('#stPrev').onclick = () => { if (ST.ch > 1) go(ST.book, ST.ch - 1); else { const i = H.BIBLE_BOOKS.findIndex(b => b[0] === ST.book); if (i > 0) go(H.BIBLE_BOOKS[i - 1][0], H.BIBLE_BOOKS[i - 1][2]); } };
  $('#stNext').onclick = () => { if (ST.ch < info[2]) go(ST.book, ST.ch + 1); else { const i = H.BIBLE_BOOKS.findIndex(b => b[0] === ST.book); if (i < H.BIBLE_BOOKS.length - 1) go(H.BIBLE_BOOKS[i + 1][0], 1); } };
  $('#stA').onchange = e => { ST.a = e.target.value; draw(); };
  $('#stB').onchange = e => { ST.b = e.target.value; draw(); };
  const alm = $('#stAlm'); if (alm) alm.onclick = installAlm;
  root.querySelectorAll('.st-v').forEach(el => {
    const tog = () => { const n = +el.dataset.n; ST.sel = ST.sel.includes(n) ? ST.sel.filter(x => x !== n) : [...ST.sel, n]; el.classList.toggle('sel'); drawFoot(); };
    el.onclick = tog; el.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); tog(); } };
  });
}

async function installAlm() {
  const msg = $('#stAlmMsg'), btn = $('#stAlm');
  try { btn.disabled = true; msg.textContent = 'Instalando…'; await H.installAlm(); }
  catch (e) { /* mensagem já mostrada */ }
  if (root) { ST.b = ST.b || 'ALM1911'; draw(); }
}

// ---------------- Comentários ----------------
async function commRows() { return (await H.all('bible')).filter(x => String(x.id).startsWith('C:')); }

async function drawComm() {
  const rows = await commRows();
  const works = [...new Set(rows.map(r => r.work))];
  if (ST.work && !works.includes(ST.work)) ST.work = '';
  const mine = rows.filter(r => r.book === ST.book && r.chapter === ST.ch && (!ST.work || r.work === ST.work));
  const nums = ST.sel;
  const covers = e => !nums.length || !e.v1 || nums.some(n => n >= e.v1 && n <= (e.v2 || e.v1));
  const items = [];
  mine.forEach(r => (r.entries || []).forEach((e, i) => { if (covers(e)) items.push({ r, e, i }); }));
  const head = `<div class="st-nav"><b>${esc(selRef())}</b>${works.length > 1 ? `<select id="stWork"><option value="">Todas as obras</option>${works.map(w => `<option${w === ST.work ? ' selected' : ''}>${esc(w)}</option>`).join('')}</select>` : ''}<button class="btn tiny" id="stImp">+ Importar comentário</button></div>`;
  const body = items.length ? items.map(({ r, e, i }, k) => {
    const foreign = r.lang && r.lang !== 'pt';
    const shown = foreign ? (e.pt || null) : e.text;
    const vr = e.v1 ? ` · v.${e.v1}${e.v2 && e.v2 !== e.v1 ? '-' + e.v2 : ''}` : ' · capítulo';
    return `<article class="st-c" data-k="${k}"><div class="st-ch"><b>${esc(r.work)}</b> <span class="muted">${esc(r.author || '')}${vr}${r.license ? ' · ' + esc(r.license) : ''}</span></div>
      ${shown ? `<p>${esc(shown)}</p>${foreign ? '<p class="st-warn">Tradução feita por IA — confira com o original.</p><details><summary>Ver original</summary><p>' + esc(e.text) + '</p></details>' : ''}` : `<details open><summary>Original (${esc(r.lang)})</summary><p>${esc(e.text)}</p></details><button class="btn tiny primary" data-tr="${k}">Traduzir com IA</button>`}
      ${shown ? `<div class="ai-bar"><button class="btn tiny" data-ins="${k}">Inserir com crédito</button></div>` : ''}</article>`;
  }).join('') : `<div class="empty">${rows.length ? 'Nenhum comentário para este trecho.' : 'Ainda não há comentários neste aparelho. Importe um arquivo .json de uma obra que você tenha direito de usar (veja o formato no manual).'}</div>`;
  if (!root) return;
  $('#stBody').innerHTML = head + `<div class="st-comms">${body}</div>${works.length ? `<details class="st-rm"><summary>Remover uma obra</summary>${works.map(w => `<button class="btn tiny danger" data-rm="${esc(w)}">Remover ${esc(w)}</button>`).join(' ')}</details>` : ''}`;
  const sw = $('#stWork'); if (sw) sw.onchange = e => { ST.work = e.target.value; draw(); };
  $('#stImp').onclick = importComm;
  root.querySelectorAll('[data-ins]').forEach(b => b.onclick = () => { const { r, e } = items[+b.dataset.ins]; const t = r.lang && r.lang !== 'pt' ? e.pt : e.text; insertInto(`“${t}” — ${r.author || r.work}, ${r.work}${r.lang !== 'pt' && r.lang ? ' (tradução por IA)' : ''}`); });
  root.querySelectorAll('[data-tr]').forEach(b => b.onclick = async () => {
    const { r, e, i } = items[+b.dataset.tr];
    if (!aiReady()) { H.toast('Configure a chave da IA em Configurações para traduzir.'); return; }
    b.disabled = true; b.textContent = 'Traduzindo…';
    try { const pt = await aiTranslate(e.text); const row = await H.get('bible', r.id); row.entries[i].pt = pt; await H.put('bible', row); draw(); }
    catch (err) { b.disabled = false; b.textContent = 'Traduzir com IA'; H.toast(err.message || 'Não foi possível traduzir.'); }
  });
  root.querySelectorAll('[data-rm]').forEach(b => b.onclick = async () => { const w = b.dataset.rm; if (!confirm('Remover "' + w + '" deste aparelho?')) return; for (const r of rows.filter(x => x.work === w)) await H.del('bible', r.id); ST.work = ''; draw(); });
}

function importComm() {
  const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.json,application/json';
  inp.onchange = async () => {
    try {
      const data = JSON.parse(await inp.files[0].text());
      const work = String(data.work || '').trim().slice(0, 80); const entries = Array.isArray(data.entries) ? data.entries : [];
      if (!work || !entries.length) throw Error('formato');
      const lang = String(data.lang || 'pt').toLowerCase().slice(0, 5);
      const groups = new Map();
      for (const e of entries) {
        const bk = H.BIBLE_BOOKS.find(b => b[0] === e.book); const ch = +e.chapter; const text = String(e.text || '').trim();
        if (!bk || !(ch >= 1 && ch <= bk[2]) || !text) continue;
        const m = String(e.verse || '').match(/^(\d+)(?:\s*[-–]\s*(\d+))?$/);
        const key = `${bk[0]}.${ch}`; if (!groups.has(key)) groups.set(key, { book: bk[0], chapter: ch, entries: [] });
        groups.get(key).entries.push({ v1: m ? +m[1] : 0, v2: m ? +(m[2] || m[1]) : 0, text, ...(typeof e.pt === 'string' ? { pt: e.pt } : {}) });
      }
      if (!groups.size) throw Error('vazio');
      const safe = work.replace(/[^\wÀ-ÿ -]/g, '');
      for (const [k, g] of groups) await H.put('bible', { id: `C:${safe}:${k}`, book: g.book, chapter: g.chapter, work, author: String(data.author || '').slice(0, 80), lang, license: String(data.license || '').slice(0, 120), entries: g.entries, updatedAt: H.now() });
      H.toast(`Comentário importado: ${groups.size} capítulo(s). Confira que você tem direito de uso.`);
      ST.work = ''; draw();
    } catch (e) { H.toast('Arquivo não reconhecido. Veja o formato no manual.'); }
  };
  inp.click();
}

// ---------------- IA ----------------
function drawAI() {
  if (!root) return;
  $('#stBody').innerHTML = `<div class="st-ai"><p><b>Alvo:</b> ${esc(selRef())} <span class="muted">(${ST.sel.length ? 'versículos selecionados' : 'capítulo inteiro'})</span></p><p class="muted">A IA explica o que você pedir, com o “porquê” e usando a Bíblia do app como fonte. Os comentaristas ficam na aba Comentários, separados da IA.</p><div class="ai-bar"><button class="btn primary" id="stAsk">Abrir ajuda da IA</button></div><p class="muted">Dica: selecione versículos na aba Bíblia para focar neles; sem seleção, a IA trabalha com o capítulo.</p></div>`;
  $('#stAsk').onclick = async () => {
    const rows = await commRows();
    const covers = e => !ST.sel.length || !e.v1 || ST.sel.some(n => n >= e.v1 && n <= (e.v2 || e.v1));
    const comments = rows.filter(r => r.book === ST.book && r.chapter === ST.ch).flatMap(r => (r.entries || []).filter(covers).map(e => `${r.work} (${r.author || ''}): ${(r.lang !== 'pt' && e.pt) || e.text}`)).join('\n\n').slice(0, 20000);
    openAISheet({ kind: 'study', ref: selRef(), text: await selText('BPM'), title: selRef(), comments, insert: t => insertInto(t) });
  };
}

// ---------------- Ilustrações (banco pessoal) ----------------
async function drawIll() {
  const items = await H.illus();
  const cur = api.get();
  const terms = H.norm([cur.title, cur.base, ...(cur.points || []).map(p => p.title)].join(' ')).split(/[^a-z0-9]+/).filter(w => w.length >= 4);
  const bookN = H.norm(String(cur.base || '').replace(/\s+\d.*$/, ''));
  const scored = items.map(x => { const hay = H.norm([x.title, (x.tags || []).join(' '), x.ref, x.text].join(' ')); let s = terms.filter(t => hay.includes(t)).length; if (bookN && H.norm(x.ref || '').startsWith(bookN)) s += 2; return { x, s, hay }; }).sort((p, q) => q.s - p.s);
  if (!root) return;
  $('#stBody').innerHTML = `<div class="field"><input id="stQ" placeholder="Buscar ilustração…" aria-label="Buscar ilustração"></div>${items.length ? '<p class="muted">As mais ligadas à sua mensagem aparecem primeiro.</p>' : ''}${items.length ? scored.map(({ x, s, hay }) => `<article class="st-c" data-hay="${esc(hay)}"><div class="st-ch"><b>${esc(x.title || '')}</b> ${s ? '<span class="tag">combina</span>' : ''}</div><p>${esc(String(x.text || '').slice(0, 400))}${String(x.text || '').length > 400 ? '…' : ''}</p><div class="ai-bar"><button class="btn tiny" data-ii="${esc(x.id)}">Inserir</button></div></article>`).join('') : '<div class="empty">Nenhuma ilustração guardada ainda. Cadastre em <b>Ilustrações</b> no menu.</div>'}`;
  const q = $('#stQ'); if (q) q.oninput = () => { const v = H.norm(q.value.trim()); root.querySelectorAll('.st-c').forEach(c => c.hidden = !!v && !c.dataset.hay.includes(v)); };
  root.querySelectorAll('[data-ii]').forEach(b => b.onclick = () => {
    const x = items.find(i => i.id === b.dataset.ii); const t = String(x.text || '') + (x.source ? ` (${x.source})` : '');
    if ((ST.dest || '').startsWith('p:')) api.setPointField(+ST.dest.slice(2), 'pi', t); else insertInto(t);
  });
}
