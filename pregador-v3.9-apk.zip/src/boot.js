// Tela de falha de inicialização (fica fora do HTML por causa da CSP: script-src 'self').
window.addEventListener('error', function (e) {
  var b = document.getElementById('boot');
  if (!b) return;
  b.innerHTML = '<div style="text-align:center;padding:24px">Não foi possível iniciar o app.<br><small style="color:#a1a1aa">' +
    String(e.message || 'erro').replace(/[<>&]/g, '') + '</small><br><br><button id="bootRetry" style="background:#ffc20e;border:0;border-radius:10px;padding:12px 20px;font-weight:700">Tentar de novo</button></div>';
  document.getElementById('bootRetry').onclick = function () { location.reload(); };
}, true);
