# Pregador+ Pro — Manual de instalação do APK (via GitHub Actions)

Tempo: cerca de 20 minutos na primeira vez. Depois, cada atualização leva ~10 minutos, quase todos esperando o GitHub compilar.

## O que acontece
Você envia os arquivos do app para o GitHub. O GitHub compila sozinho o APK (num computador deles, de graça) e deixa o arquivo `.apk` pronto para baixar no celular. Você não instala nada no seu computador além do `git` (se usar o terminal).

---

## 1. Criar a conta e o repositório
1. Crie uma conta gratuita em https://github.com (se ainda não tiver).
2. Clique em **+ → New repository**.
3. Nome: `pregador-plus`. Marque **Private** (privado — recomendado: só você vê o código).
4. **Não** marque "Add a README". Clique em **Create repository**.

## 2. Enviar os arquivos para o GitHub
Descompacte o zip do app numa pasta. Escolha **uma** das opções.

### Opção A — pelo terminal (Linux do Chromebook)
Na pasta do app:
```
git init
git add -A
git commit -m "Pregador+ v3.2"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/pregador-plus.git
git push -u origin main
```
Troque `SEU-USUARIO` pelo seu usuário. Quando pedir senha, use um **token**: GitHub → Settings → Developer settings → Personal access tokens → *Tokens (classic)* → Generate new token → marque **repo** e **workflow** → copie e cole no lugar da senha.

### Opção B — pelo site (sem terminal)
1. No repositório vazio, clique em **uploading an existing file**.
2. Arraste **todo o conteúdo** da pasta (arquivos e as pastas `src`, `assets`, `screenshots`, `scripts`, `signing`, `.well-known`). Clique em **Commit changes**.
3. **Atenção:** pastas que começam com ponto (`.github`) podem não aparecer no gerenciador de arquivos. Por isso, crie o arquivo do compilador à mão:
   - **Add file → Create new file**
   - No nome, digite exatamente: `.github/workflows/android-apk.yml`
   - Abra o arquivo `android-apk.yml` do zip (no Chromebook: Arquivos → ⋮ → *Mostrar arquivos ocultos*), copie todo o texto e cole.
   - **Commit changes**.
4. Confira se a pasta `signing` tem o arquivo `debug.keystore`. Ele é obrigatório (veja a seção 8).

## 3. Gerar o APK
1. No repositório, abra a aba **Actions**.
2. Se aparecer um botão verde para habilitar, clique nele.
3. Clique em **Gerar APK** (lado esquerdo) → **Run workflow** → **Run workflow**.
   (Também roda sozinho toda vez que você envia arquivos novos.)
4. Espere de 5 a 10 minutos. Quando aparecer o ✅ verde, terminou.
   - Se aparecer ❌ vermelho, veja a seção 9.

## 4. Baixar o APK
Pelo celular (logado no GitHub no navegador):
1. Abra o repositório → à direita, **Releases** → a versão mais recente (ex.: *Pregador+ build 1*).
2. Em **Assets**, toque em `Pregador-Plus-3.2.0-build1.apk`.

Outra forma: aba **Actions** → o run → **Artifacts** → `pregador-plus-apk` (baixa um .zip; descompacte para pegar o .apk).

## 5. Instalar no celular ou tablet
1. Abra o arquivo `.apk` baixado.
2. Se pedir, toque em **Configurações** e ative **Permitir desta fonte** para o navegador (ou o app Arquivos) que você usou.
3. Se o Google Play Protect avisar "app não verificado", toque em **Instalar mesmo assim**. É normal: o app é seu e não está na Play Store.
4. Toque em **Instalar** → **Abrir**.

Pelo ADB (se preferir): `adb install -r Pregador-Plus-3.2.0-build1.apk`

## 6. Primeiro uso
1. Conectado ao Wi-Fi: **Bíblia → Instalar Bíblia** (baixa uma vez e depois funciona offline).
2. **Configurações → Assistente de IA**: cole a chave do Google AI Studio (https://aistudio.google.com/apikey) → Salvar → Testar conexão.
3. Ao gravar áudio ou ditar, o Android pedirá permissão do microfone: toque em **Permitir**.

## 7. Atualizar o app no futuro
1. **Faça um backup antes** (Arquivos → Backup): o Android abre o compartilhamento; salve no Drive ou em Arquivos.
2. Envie os arquivos novos para o GitHub (mesmos passos da seção 2; substitui os antigos).
3. Espere o ✅ em Actions, baixe o novo `.apk` e instale **por cima** do app atual.
Seus dados são mantidos, porque a assinatura é sempre a mesma e o número da versão sobe a cada build.

## 8. Regras importantes
- **Nunca apague nem troque** `signing/debug.keystore`. Se a assinatura mudar, o Android não deixa instalar por cima e você teria que desinstalar (e perderia os dados que não estejam no backup).
- Mantenha o repositório **privado**. A chave de IA **não** vai para o GitHub (fica só no aparelho). Não escreva chaves dentro dos arquivos do app.
- Este APK é de uso pessoal (assinatura de teste). Para publicar na Play Store, o caminho é outro (veja `GERAR-APK.md`).
- Plano gratuito do GitHub: 2.000 minutos de compilação por mês em repositório privado. Cada build usa ~10.

## 9. Problemas comuns
| Problema | O que fazer |
|---|---|
| ❌ no Actions | Clique no run vermelho → no passo com ❌ → copie as últimas linhas do erro e me envie. |
| "App não instalado" | Já existe outro Pregador+ com assinatura diferente (ex.: versão do PWABuilder). Faça backup, desinstale o antigo e instale este. |
| Não aparece Releases | Confira se o run terminou com ✅ e se o arquivo `.github/workflows/android-apk.yml` está igual ao do zip (tem a linha `contents: write`). |
| Ditado por voz não abre | No APK ele usa o reconhecimento do Google (precisa de internet e do app Google instalado). |
| Leitor de PDF em branco | O leitor embutido pode não funcionar dentro do APK. Use o PWA no Chrome para PDFs. |
| Bíblia não baixa | Precisa de internet na primeira vez; tente de novo no Wi-Fi. |
| IA com erro 429 | Limite gratuito do Gemini; espere um pouco. Erro 404: Configurações → *Buscar modelos* e escolha outro. |

## 10. Prefere sem APK?
O app também funciona como PWA: hospede a pasta no Netlify, abra no Chrome do celular → menu ⋮ → **Instalar aplicativo**. Veja `GERAR-APK.md`.

---
*Observação: o fluxo de compilação foi validado até a criação do projeto Android (plugins, permissões, ícones e versão). A compilação final do APK acontece no GitHub e eu não consegui executá-la no meu ambiente; se falhar, o log do Actions mostra o passo exato.*

---
## Novidades da versão 3.3 (como usar)
- **Colar esboço**: Mensagens → "Colar esboço" (como colado, organizar sem IA ou com IA preservando suas palavras).
- **Tempo por tópico**: campo "min" em cada tópico; na tela Pregar a cor avisa (verde/amarelo/vermelho), sem som.
- **Histórico de pregações**: menu "Histórico"; use "Encerrar e registrar" ao terminar.
- **Exportar**: no editor da mensagem, botão "Exportar" → PDF, .txt, .md ou compartilhar.
- **Outras traduções**: Bíblia → "+ Importar tradução" (arquivo .json seu: `{"abbr":"ARC","books":[{"name":"João","chapters":[{"chapter":3,"verses":[{"verse":16,"text":"..."}]}]}]}`). Use apenas textos que você tem direito de usar. A IA e a conferência continuam usando a BPM.
- **Lembrete de backup**: aviso na Home após 7 dias sem backup.
- **Mesclar backup** (Configurações): junta um backup de outro aparelho ao atual; vence o item com `updatedAt` mais recente. Não há sincronização automática (exigiria servidor).
- **Cuidados com a chave Gemini**: não compartilhe; se ativar cobrança, crie orçamento com alerta no Google Cloud; se perder o aparelho, apague/troque a chave em aistudio.google.com/apikey. A chave não vai no backup.

---
## Versão 3.4 — Estúdio de estudo
No editor da mensagem, botão **Estudo** (a tela de Pregar não muda).
- **Tablet/PC:** tela dividida, esboço à esquerda e estudo à direita. **Celular:** o estudo abre por cima; "← Esboço" volta.
- **Bíblia:** BPM + Almeida 1911 (domínio público, botão Instalar, ~4 MB, funciona offline) + qualquer tradução importada. Compare duas versões versículo a versículo. Toque nos versículos, escolha o destino (novo tópico, tópico, introdução, contexto, conclusão) e toque em Inserir.
- **Comentários:** importe um `.json` de obra que você tenha direito de usar:
  `{"work":"Nome da obra","author":"Autor","lang":"pt","license":"Domínio público","entries":[{"book":"João","chapter":3,"verse":"16","text":"..."}]}`
  (`verse` pode ser "16-18" ou vazio para o capítulo inteiro). Se `lang` não for `pt`, o botão **Traduzir com IA** traduz, salva e marca "Tradução feita por IA".
- **IA:** explica o trecho ou o capítulo, contexto histórico, palavras-chave, textos relacionados, interpretações e cuidados, resumo dos comentários abertos. Sempre com o "porquê" e a Bíblia do app como fonte. Os comentaristas ficam separados da IA.

---
## Versão 3.5 — Plano, revisão, ilustrações e busca
- **Plano** (menu Preparar): marque data, texto base, série e status (Estudando → Esboçado → Pronto → Pregado; toque na etiqueta para mudar). "Criar mensagem" gera a mensagem já ligada ao plano. A Home mostra a próxima pregação e o plano avisa quantas vezes você já pregou no mesmo livro. Ao registrar a pregação, o item vira "Pregado".
- **Revisão pós-pregação:** ao "Encerrar e registrar", responda: o que funcionou, o que cortar, o que repetir. Aparece no Histórico e, na próxima vez, no topo da mensagem.
- **Ilustrações** (menu Estudar): banco pessoal com título, texto, etiquetas, texto bíblico e fonte; busca instantânea. No Estúdio de estudo, a aba **Ilustrações** sugere as que combinam com a mensagem e insere no tópico.
- **Busca:** agora também acha plano, ilustrações e pregações registradas.

---
## Versão 3.6 — Menu enxuto
O menu caiu de 16 para 7 destinos, sem apagar nada:
- **Mensagens** (abas: Mensagens · Plano · Histórico) · **Bíblia** (abas: Bíblia · Ilustrações) · **Caderno** (abas: Caderno · Estudos · Favoritos).
- **Pregar** agora está na barra de baixo do celular.
- **Mais** (no menu): Anotar esboço falado, Cursos e aulas, Ouvir, Arquivos. Seus dados continuam todos no app e no backup.
- A Home ficou só com a próxima pregação, continuar de onde parou e a Bíblia offline.

---
## Versão 3.7 — Correções do APK
- **Botão Voltar do Android:** fecha o que estiver aberto (janelas, estúdio, IA), sai do editor ou da pregação, volta para a Home e, na Home, pede para tocar de novo para sair.
- **Telas cortadas / deslocadas para o lado:** corrigido o estouro de largura em Configurações e travado o deslocamento lateral em todas as telas.
- **Configurações:** textos de Netlify/instalação removidos dentro do APK; mostra a versão e o backup.
